//package AI;
//
//import java.util.ArrayList;
//import java.util.LinkedList;
//import java.util.Random;
//
//import units.Unit;
//import view.UnitSelection;
//import view.ViewCharacter;
//
//public abstract class ArtificialUser {
//
//	private Unit unit;
//	private ArrayList enemyList; // not a unit but a list
//	private Random random;
//	private boolean move;
//	
//	private int numArch;
//	private int numGenie;
//	private int numGoblin;
//	private int numKnight;
//	private int numMage;
//	private int numRanger;
//	private int numThief;
//	private int numWarrior;
//	
//	private ViewCharacter charater;
//	
//	ArrayList AIUnits;
//	
//	public ArtificialUser()
//	{
//		
//		move = true;
//		AIUnits = new ArrayList();
//		charater = new ViewCharacter(unit);
//		
//	}
//	
//	public abstract void pickUnitList();
//	
//	
//	private String getUnitType()
//	{
//		
//		return unit.getTitle();
//	}
//	
//	public abstract void strategy();
//	
//	private void usePotion()
//	{
//		
//		
//		
//	}
//	
//	private void position()
//	{
//		
//		
//		
//	}
//	
//}
