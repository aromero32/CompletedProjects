//package AI;
//
//import java.util.ArrayList;
//import java.util.Random;
//
//import units.Archer;
//import units.Unit;
//
//public class MonsterSpawn extends ArtificialUser {
//	
//	private Unit unit;
//	private ArrayList enemyList; // not a unit but a list
//	private Random random;
//	
//	ArrayList AIUnits;
//	
//	public MonsterSpawn()
//	{
//	
//		pickUnitList();
//		
//	}
//	
//	@Override
//	public void pickUnitList()
//	{
//		random = new Random();
//		int listNum = random.nextInt(3);
//		
//		for(int count = enemyList.size(); count>0; count--)
//		{
//			
//			// use the code they have for the goblins
//			
//		}
//		
//	}
//	
//	private String getUnitType()
//	{
//		
//		return unit.getTitle();
//	}
//	
//	public void strategy()
//	{
//		
//		
//		
//	}
//	
//	private void usePotion()
//	{
//		
//		
//		
//	}
//	
//	
//
//}
