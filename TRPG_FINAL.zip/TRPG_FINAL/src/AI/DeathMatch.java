//package AI;
//
//import java.util.ArrayList;
//import java.util.Random;
//
//import units.Archer;
//import units.Genie;
//import units.Goblin;
//import units.Knight;
//import units.Mage;
//import units.Ranger;
//import units.Unit;
//import units.Warrior;
//
//public class DeathMatch extends ArtificialUser {
//	
//	private Unit unit;
//	private ArrayList enemyList; // not a unit but a list
//	private Random random;
//	
//	ArrayList AIUnits;
//	
//	int row;
//	int col;
//	int rowDis;
//	int colDis;
//	
//	public DeathMatch(ArrayList enemy)
//	{
//		
//		
//		
//	}
//
//	
//	public void pickUnitList()
//	{
//		random = new Random();
//		int listNum = random.nextInt(3);
//		
//		for(int count = enemyList.size(); count>0; count--)
//		{
//			
//			if(count !=0)
//			{
//				AIUnits.add(new Archer());
//				count--;
//			}
//			if(count !=0)
//			{
//				AIUnits.add(new Genie());
//				count--;
//			}
//			if(count !=0)
//			{
//				AIUnits.add(new Goblin());
//				count--;
//			}
//			if(count !=0)
//			{
//				AIUnits.add(new Knight());
//				count--;
//			}
//			if(count !=0)
//			{
//				AIUnits.add(new Mage());
//				count--;
//			}
//			if(count != 0)
//			{
//				AIUnits.add(new Ranger());
//				count--;
//			}
//			/*if(count != 0)
//			{
//				AIUnits.add(new Theif());
//				count--;
//			}*/
//			if(count != 0)
//			{
//				AIUnits.add(new Warrior());
//			}
//			
//		}
//		
////	}
//	
//	private String getUnitType()
//	{
//		
//		return unit.getTitle();
//		
//	}
//	
//	public boolean inRange()
//	{
//		for(int i = row)
//		{
//			for()
//			{
//				
//			}
//		}// check radius to see if enemy is in range
//		return false;
//		
//	}
//	
//	@Override
//	public void strategy()
//	{
//		
//		row = unit.getRow();
//		col = unit.getCol();
//		// if the enemy has passed one of the units, and is more than halfway down, change strategy
//		if()
//		{
//		if(0 < col)
//		{
//			// find the path to take
//			row = row - unit.getMovementSpeed();
//			col = col - unit.getMovementSpeed();
//			//if map at this location is blocked
//			row = ((row +1)- unit.getMovementSpeed());
//			col = col - unit.getMovementSpeed();
//		}
//		
//		if( inRange() && getHealth()<= getHealth())
//		{
//			// first unit in range and attack them.
//		}
//		
//	}
//	
//	private void usePotion()
//	{
//		
//		
//		
//	}
//
//}
