//package AI;
//
//import java.util.ArrayList;
//import java.util.Random;
//
//import model.Player1;
//import model.Player2;
//import units.Archer;
//import units.Genie;
//import units.Goblin;
//import units.Knight;
//import units.Mage;
//import units.Ranger;
//import units.Unit;
//import units.Warrior;
//
//public class HillKing extends ArtificialUser {
//	
//	private Unit unit;
//	private ArrayList enemyList; // not a unit but a list
//	private Random random;
//	
//	ArrayList AIUnits;
//	
//	int row;
//	int col;
//	int rowDis;
//	int colDis;
//	 
//	
//	public HillKing()
//	{
//		
//		pickUnitList();
//		
//	}
//	
//	
//	public void pickUnitList()
//	{
//		random = new Random();
//		int listNum = random.nextInt(3);
//		
//		for(int count = enemyList.size(); count>0; count--)
//		{
//			
//			if(count !=0)
//			{
//				AIUnits.add(new Archer());
//				count--;
//			}
//			if(count !=0)
//			{
//				AIUnits.add(new Genie());
//				count--;
//			}
//			if(count !=0)
//			{
//				AIUnits.add(new Goblin()));
//				count--;
//			}
//			if(count !=0)
//			{
//				AIUnits.add(new Knight());
//				count--;
//			}
//			if(count !=0)
//			{
//				AIUnits.add(new Mage());
//				count--;
//			}
//			if(count != 0)
//			{
//				AIUnits.add(new Ranger());
//				count--;
//			}
//			/*if(count != 0)
//			{
//				AIUnits.add(new Theif());
//				count--;
//			}*/
//			if(count != 0)
//			{
//				AIUnits.add(new Warrior());
//			}
//			
//		}
//		
//	}
//	
//	private String getUnitType()
//	{
//		
//		return unit.getTitle();
//	}
//	
//	
//	
//	public boolean inRange(int row, int col)
//	{
//		for(int i = row)
//		{
//			for()
//			{
//				
//			}
//		}// check radius to see if enemy is in range
//		return false;
//		
//	}
//	
//	private boolean halfway()
//	{
//		
//		for(Unit player1: Player1.getUnitsInstance())
//		{
//		
//			if(player1.getRow()>13)
//			{
//				return true;
//			}
//			
//		}
//		
//		return false;
//		
//	}
//	
//	private boolean halfwayAI()
//	{
//			
//			for(Unit player2: Player2.getUnitsInstance())
//			{
//			
//				if(player2.getRow()<13)
//				{
//					return true;
//				}
//				
//			}
//			
//			return false;
//			
//		
//	} //
//	
//	@Override
//	public void strategy()
//	{
//		
//			if(!halfway()||halfwayAI())// will use capture flag strategy
//			{
//				//iteration for selecting each unit for its turn
//				for(Unit unit: Player2.getUnitsInstance())
//				{
//						row = unit.getRow();
//						col = unit.getCol();
//						
//						// if the enemy has passed one of the units, and is more than halfway down, change strategy
//						
//					if(3 < col)
//					{
//						
//						// find the path to take
//						row = row - unit.getMovementSpeed();
//						col = col - unit.getMovementSpeed();
//						//if map at this location is blocked
//						row = ((row +1)- unit.getMovementSpeed());
//						col = col - unit.getMovementSpeed();
//					}
//					
//					if( inRange(row, col) && getHealth()<= getHealth())
//					{
//						// first unit in range and attack them.
//					}
//					
//					// end of turn
//				}
//			}
//			else // will use attack strategy
//			{
//				int close = 0;
//				int prevClose = 0;
//				Unit temp = null;
//				
//				for(Unit unit: Player1.getUnitsInstance())
//				{
//					close = unit.getRow() + unit.getCol();
//					if ( close > prevClose)
//					{
//						prevClose = close;
//						temp = unit;
//					}
//				}
//				
//				//if(unit.inRange())
//				
//			}
//		
//		
//	}
//	
//	private void usePotion()
//	{
//		
//		// get the potion
//		
//	}
//
// }
