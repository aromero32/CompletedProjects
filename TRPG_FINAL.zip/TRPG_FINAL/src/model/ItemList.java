/*
 * /////////////////////////////////////////////////////////////////// 
 * TEAM: ROSARIO RIVERA, ALEX ROMERO
 * 
 * PURPOSE: MAKES A PLAYLIST THAT HAS ALL THE SONGS THAT NEED TO BE PLAYED
 * 
 * 
 * 
 */// ////////////////////////////////////////////////////////////

package model;

import items.Item;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;

import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;

@SuppressWarnings("serial")
public class ItemList implements TableModel, Serializable {

	private ArrayList<Item> items;
	private LinkedList<ListDataListener> listDataListeners;
	private LinkedList<TableModelListener> tableModelListeners;

	// creates the playlist and adds all of the listeners
	public ItemList() {

		items = new ArrayList<Item>();
		listDataListeners = new LinkedList<ListDataListener>();
		tableModelListeners = new LinkedList<TableModelListener>();

	}

	// adds a song to songs
	public void add(Item item) {
		items.add(item);
		changed();
	}

	// removes a song
	public void remove(Item item) {
		items.remove(item);
		changed();
	}

	// changes the songs for the data listener
	public void changed() {
		for (ListDataListener l : listDataListeners) {
			l.contentsChanged(new ListDataEvent(this,
					ListDataEvent.CONTENTS_CHANGED, 0, items.size()));
		}

	}

	// gets row count
	public int getRowCount() {
		// TODO Auto-generated method stub
		return items.size();
	}

	// gets column count
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return 2;
	}

	// sets and gets the name of each column
	public String getColumnName(int columnIndex) {
		switch (columnIndex) {

		case 0:
			return "Item";
		case 1:
			return "Description";

		}
		return null;
	}

	// returns the class for each column
	public Class<?> getColumnClass(int columnIndex) {
		switch (columnIndex) {

		case 0:
		case 1:
			return String.class;
		}
		return null;
	}

	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return false;
	}

	// what is in each column
	public Object getValueAt(int rowIndex, int columnIndex) {
		switch (columnIndex) {
		case 0:
			return items.get(rowIndex).getName();
		case 1:
			return items.get(rowIndex).toString();
		}
		return null;
	}

	public Item getItemAt(int rowIndex, int columnIndex) {
		switch (columnIndex) {
		case 0:
		case 1:

			return items.get(rowIndex);

		}
		return null;

	}

	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		// do not implement

	}

	// adds table listeners
	public void addTableModelListener(TableModelListener l) {
		tableModelListeners.add(l);
	}

	// removes table listeners
	public void removeTableModelListener(TableModelListener l) {
		tableModelListeners.remove(l);
	}

	public ArrayList<Item> getItems() {
		return items;
	}
}
