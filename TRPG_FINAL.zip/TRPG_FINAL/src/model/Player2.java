package model;

import items.Item;

import java.io.Serializable;
import java.util.ArrayList;

import units.Captain;
import units.Goblin;
import units.Mage;
import units.Troll;
import units.Unit;
import view.UnitSelection;

/*
 * Singleton class keeps track of the players List of Items and list of Units
 */
public class Player2 implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9209233650542740170L;
	private static ArrayList<Unit> units;

	private static ArrayList<Unit> hordeUnits;

	private static ArrayList<Item> items;
	private static int potionQuantity = 3;
	private static int attackQuantity = 3;
	private static int speedQuantity = 3;
	private static Unit captain;
	private static int aliveUnits;

	private Player2() {
	}

	public static ArrayList<Unit> getUnitsInstance() {
		if (units == null) {
			units = new ArrayList<Unit>();
			if (!UnitSelection.isHorde()) {
				setUnits();
			}
		}
		return units;
	}

	public static void setUnits() {
		units.add(new Captain());
		for (int count = Player1.getUnitsInstance().size() - 1; count > 0; count--) {

			if (count != 0) {
				units.add(new Troll());
				count--;
			}
			if (count != 0) {
				units.add(new Goblin());
				count--;
			}
			if (count != 0) {
				units.add(new Goblin());
				count--;
			}
			if (count != 0) {
				units.add(new Goblin());
				count--;
			}
			if (count != 0) {
				units.add(new Mage());
				count--;
			}
			if (count != 0) {
				units.add(new Goblin());
				count--;
			}
			if (count != 0) {
				units.add(new Goblin());
			}

		}

		int count = 0;
		for (Unit unit : units) {
			unit.setTeam(2);
			unit.setPlace("Unit" + count);
			unit.setCanMove(false);
			unit.setCanAttack(false);
			count++;
		}
	}

	@Override
	public String toString() {
		String UnitList = "Units = ";
		String ItemList = "Items = ";
		for (Unit unit : units) {
			UnitList += unit.getTitle();
		}
		for (Item item : items) {
			ItemList += item.getName();
		}
		return ItemList + "\n" + UnitList;
	}

	/**
	 * @return the speedQuantity
	 */
	public static int getSpeedQuantity() {
		return speedQuantity;
	}

	/**
	 * @param speedQuantity
	 *            the speedQuantity to set
	 */
	public static void setSpeedQuantity(int speedQuantity) {
		Player2.speedQuantity = speedQuantity;
	}

	/**
	 * @return the attackQuantity
	 */
	public static int getAttackQuantity() {
		return attackQuantity;
	}

	/**
	 * @param attackQuantity
	 *            the attackQuantity to set
	 */
	public static void setAttackQuantity(int attackQuantity) {
		Player2.attackQuantity = attackQuantity;
	}

	/**
	 * @return the potionQuantity
	 */
	public static int getPotionQuantity() {
		return potionQuantity;
	}

	/**
	 * @param potionQuantity
	 *            the potionQuantity to set
	 */
	public static void setPotionQuantity(int potionQuantity) {
		Player2.potionQuantity = potionQuantity;
	}

	/**
	 * @return the captain
	 */
	public static Unit getCaptain() {
		return captain;
	}

	/**
	 * @param captain
	 *            the captain to set
	 */
	public static void setCaptain() {
		if (UnitSelection.isHorde()) {
			captain = hordeUnits.get(0);
		} else {

			captain = units.get(0);
		}
	}

	/**
	 * @return the hordeUnits
	 */
	public static ArrayList<Unit> getHordeUnits() {
		if (hordeUnits == null) {
			hordeUnits = new ArrayList<Unit>();
			setHordeUnits();
		}
		return hordeUnits;
	}

	/**
	 * @param hordeUnits
	 *            the hordeUnits to set
	 */
	public static void setHordeUnits() {
		hordeUnits.add(new Captain());
		hordeUnits.add(new Troll());
		hordeUnits.add(new Troll());
		hordeUnits.add(new Goblin());
		hordeUnits.add(new Goblin());
		hordeUnits.add(new Goblin());
		hordeUnits.add(new Goblin());
		hordeUnits.add(new Goblin());
		hordeUnits.add(new Goblin());
		hordeUnits.add(new Goblin());
		hordeUnits.add(new Goblin());
		hordeUnits.add(new Goblin());

		int count = 0;
		for (Unit unit : hordeUnits) {
			unit.setPlace("Unit" + count);
			unit.setTeam(2);
			unit.setCanMove(false);
			unit.setCanAttack(false);
			count++;
		}

	}

	public static int getUnitsLeftNumber() {
		if (UnitSelection.isHorde()) {
			aliveUnits = hordeUnits.size() - 1;
			for (Unit unit : hordeUnits) {
				if (!unit.isAlive()) {
					aliveUnits--;
				}
			}
		} else {
			aliveUnits = units.size() - 1;
			for (Unit unit : units) {
				if (!unit.isAlive()) {
					aliveUnits--;
				}
			}
		}
		return aliveUnits;
	}

	public static void reset() {
		units = new ArrayList<Unit>();
		hordeUnits = new ArrayList<Unit>();
		setHordeUnits();
		setUnits();

	}

}