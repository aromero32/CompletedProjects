package model;

import java.util.ArrayList;

import units.Unit;



public class User {
	
	private String name;
	private ArrayList<Unit> units;
	
	public User(String name) {
		this.name = name;

	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public ArrayList<Unit> getUnits() {
		return units;
	}
	
	public void setUnits(ArrayList<Unit> units) {
		this.units = units;
	}
	
	
	@Override
	public String toString() {
		String result = name + " ";
		
		 for(Unit unit: units){
			 result+= unit.getTitle();			 
		 }
		
		return result;
		
	}

}
