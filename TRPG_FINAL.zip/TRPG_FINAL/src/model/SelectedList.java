/*
 * /////////////////////////////////////////////////////////////////// 
 * TEAM: ROSARIO RIVERA, ALEX ROMERO
 * 
 * PURPOSE: MAKES A PLAYLIST THAT HAS ALL THE SONGS THAT NEED TO BE PLAYED
 * 
 * 
 * 
 */// ////////////////////////////////////////////////////////////

package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;

import javax.swing.ListModel;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;

import units.Unit;

@SuppressWarnings("serial")
public class SelectedList implements ListModel<Unit>, TableModel, Serializable {

	private ArrayList<Unit> units;
	private LinkedList<ListDataListener> listDataListeners;
	private LinkedList<TableModelListener> tableModelListeners;

	// creates the playlist and adds all of the listeners
	public SelectedList() {
		units = new ArrayList<Unit>();
		listDataListeners = new LinkedList<ListDataListener>();
		tableModelListeners = new LinkedList<TableModelListener>();

	}

	// adds a song to songs
	public void add(Unit unit) {
		units.add(unit);
		changed();
	}

	// removes a song
	public void remove(Unit unit) {
		units.remove(unit);
		changed();
	}

	// changes the songs for the data listener
	public void changed() {
		for (ListDataListener l : listDataListeners) {
			l.contentsChanged(new ListDataEvent(this,
					ListDataEvent.CONTENTS_CHANGED, 0, units.size()));
		}

	}

	/* start of list model stuff */
	public int getSize() {
		return units.size();
	}

	// gets element of song
	public Unit getElementAt(int index) {
		if (index < 0 || index >= units.size()) {
			return null;
		}
		return units.get(index);
	}

	// adds listener
	public void addListDataListener(ListDataListener l) {
		listDataListeners.add(l);

	}

	// removes listener
	public void removeListDataListener(ListDataListener l) {
		listDataListeners.remove(l);
	}

	/* end of list model stuff */

	// gets row count
	public int getRowCount() {
		// TODO Auto-generated method stub
		return units.size();
	}

	// gets column count
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return 4;
	}

	// sets and gets the name of each column
	public String getColumnName(int columnIndex) {
		switch (columnIndex) {

		case 0:
			return "Unit Type";
		case 1:
			return "Health";
		case 2:
			return "Attack";
		case 3:
			return "Movement Speed";

		}
		return null;
	}

	// returns the class for each column
	public Class<?> getColumnClass(int columnIndex) {
		switch (columnIndex) {

		case 0:
			return String.class;
		case 1:
		case 2:
		case 3:
			return Integer.class;
		}
		return null;
	}

	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return false;
	}

	// what is in each column
	public Object getValueAt(int rowIndex, int columnIndex) {
		switch (columnIndex) {
		case 0:
			return units.get(rowIndex).getTitle();
		case 1:
			return units.get(rowIndex).getMaxHealth();
		case 2:
			return units.get(rowIndex).getAttackDamage();
		case 3:
			return units.get(rowIndex).getMovementSpeed();
		}
		return null;
	}

	public Unit getUnitAt(int rowIndex, int columnIndex) {
		switch (columnIndex) {
		case 0:
		case 1:
		case 2:
		case 3:

			return units.get(rowIndex);

		}
		return null;

	}

	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		// do not implement

	}

	// adds table listeners
	public void addTableModelListener(TableModelListener l) {
		tableModelListeners.add(l);
	}

	// removes table listeners
	public void removeTableModelListener(TableModelListener l) {
		tableModelListeners.remove(l);
	}

	public ArrayList<Unit> getUnits() {
		return units;
	}
}
