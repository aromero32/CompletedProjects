package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;

import units.Unit;

@SuppressWarnings("serial")
public class UnitCollectionAgain implements TableModel, Serializable {

	private ArrayList<Unit> UnitList;
	private Map<String, Unit> Units;

	private LinkedList<TableModelListener> tableModelListeners;

	// constructor for a new Unit Collection
	public UnitCollectionAgain() {
		UnitList = new ArrayList<Unit>();
		Units = new HashMap<String, Unit>();
		tableModelListeners = new LinkedList<TableModelListener>();

	}

	// adds a new Unit
	public void add(Unit Unit) {
		UnitList.add(Unit);
		Units.put(Unit.getTitle(), Unit);
		tableModelListeners = new LinkedList<TableModelListener>();

		changed();
	}

	// sets things to changed
	public void changed() {
		for (TableModelListener t : tableModelListeners) {
			t.tableChanged(new TableModelEvent((TableModel) this));
		}

	}

	// gets row count
	public int getRowCount() {
		// TODO Auto-generated method stub
		return Player1.getUnitsInstance().size();
	}

	// gets column count
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return 4;
	}

	// sets and gets the name of each column
	public String getColumnName(int columnIndex) {
		switch (columnIndex) {

		case 0:
			return "Unit Type";
		case 1:
			return "Health";
		case 2:
			return "Attack";
		case 3:
			return "Movement Speed";
		}
		return null;
	}

	// returns the class for each column
	public Class<?> getColumnClass(int columnIndex) {
		switch (columnIndex) {

		case 0:
			return String.class;
		case 1:
		case 2:
		case 3:
			return Integer.class;
		}
		return null;
	}

	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return false;
	}

	// what is in each column
	public Object getValueAt(int rowIndex, int columnIndex) {
		switch (columnIndex) {
		case 0:
			return UnitList.get(rowIndex).getTitle();
		case 1:
			return UnitList.get(rowIndex).getCurrentHealth();
		case 2:
			return UnitList.get(rowIndex).getAttackDamage();
		case 3:
			return UnitList.get(rowIndex).getMovementSpeed();
		}
		return null;
	}

	public Unit getUnitAt(int rowIndex, int columnIndex) {
		switch (columnIndex) {
		case 0:
		case 1:
		case 2:
		case 3:

			return UnitList.get(rowIndex);

		}
		return null;

	}

	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		// do not implement

	}

	// adds table listeners
	public void addTableModelListener(TableModelListener l) {
		tableModelListeners.add(l);
	}

	// removes table listeners
	public void removeTableModelListener(TableModelListener l) {
		tableModelListeners.remove(l);
	}

	// returns a HashMap of Units
	public HashMap<String, Unit> getUnits() {
		return (HashMap<String, Unit>) Units;
	}

	public void setUnits(HashMap<String, Unit> units) {
		Units = (HashMap<String, Unit>) units;
	}

	public ArrayList<Unit> getUnitList() {
		return UnitList;
	}

}
