package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

import units.Unit;
import units.no;
import view.UnitSelection;

public class Maps implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4263148022066292867L;

	private static final int SIZE = 26; // the size of the 2D array

	private Room[][] map1 = new Room[SIZE][SIZE]; // this is meadows
	private Room[][] map2 = new Room[SIZE][SIZE]; // this is other one

	private ArrayList<Unit> p1Units;
	private ArrayList<Unit> p2Units;
	private Random randy = new Random();

	public Maps() {
		if (!UnitSelection.isHorde()) {
			this.setP1Units(Player1.getUnitsInstance());
			this.setP2Units(Player2.getUnitsInstance());
		} else if (UnitSelection.isHorde()) {
			this.setP1Units(Player1.getUnitsInstance());
			this.setP2Units(Player2.getHordeUnits());
		}

		Player2.setCaptain();
		Player1.setCaptain();

		makeMap1();
		makeMap2();
		map1[3][3].setObstruction(false);
		map1[22][22].setObstruction(false);
		map2[3][3].setObstruction(false);
		map2[22][22].setObstruction(false);
	}

	private void placeP1M1() {
		int r = 4;
		int c = 4;
		if (UnitSelection.isHorde()) {
			r = 7;
			c = 4;
			map1[11][3].setUnitInMap(Player1.getUnitsInstance().get(0));
			map1[11][3].getUnit().setRow(3);
			map1[11][3].getUnit().setCol(11);
			map1[11][3].setHasUnit(true);

			for (int i = 1; i < Player1.getUnitsInstance().size(); i++) {
				// Player2.getHordeUnits().get(i).setTeam(2);

				map1[r][c].setUnitInMap(Player1.getUnitsInstance().get(i));
				Player1.getUnitsInstance().get(i).setRow(c);
				Player1.getUnitsInstance().get(i).setCol(r);
				map1[r][c].setHasUnit(true);
				r += 3;

			}

		} else {
			for (Unit unit : Player1.getUnitsInstance()) {

				if (r > 4 && c > 4) {
					c = 6;
					r = 6;
					map1[r][c].setUnitInMap(unit);
					map1[r][c].getUnit().setRow(c);
					map1[r][c].getUnit().setCol(r);
					map1[r][c].setHasUnit(true);
				} else if (c <= 12) {
					map1[r][c].setUnitInMap(unit);
					unit.setRow(c);
					unit.setCol(r);
					map1[r][c].setHasUnit(true);
					c += 4;
				} else {
					c = 4;
					r += 4;
					map1[r][c].setUnitInMap(unit);
					unit.setRow(c);
					unit.setCol(r);
					map1[r][c].setHasUnit(true);
					r += 4;
				}
			}
		}

	}

	private void placeP1M2() {

		int r = 4;
		int c = 4;
		if (UnitSelection.isHorde()) {
			r = 7;
			c = 4;
			map2[11][3].setUnitInMap(Player1.getUnitsInstance().get(0));
			map2[11][3].getUnit().setRow(3);
			map2[11][3].getUnit().setCol(11);
			map2[11][3].setHasUnit(true);

			for (int i = 1; i < Player1.getUnitsInstance().size(); i++) {
				// Player2.getHordeUnits().get(i).setTeam(2);

				map2[r][c].setUnitInMap(Player1.getUnitsInstance().get(i));
				Player1.getUnitsInstance().get(i).setRow(c);
				Player1.getUnitsInstance().get(i).setCol(r);
				map2[r][c].setHasUnit(true);
				r += 3;

			}

		} else {
			for (Unit unit : Player1.getUnitsInstance()) {

				if (r > 4 && c > 4) {
					c = 6;
					r = 6;
					map2[r][c].setUnitInMap(unit);
					map2[r][c].getUnit().setRow(c);
					map2[r][c].getUnit().setCol(r);
					map2[r][c].setHasUnit(true);
				} else if (c <= 12) {
					map2[r][c].setUnitInMap(unit);
					unit.setRow(c);
					unit.setCol(r);
					map2[r][c].setHasUnit(true);
					c += 4;
				} else {
					c = 4;
					r += 4;
					map2[r][c].setUnitInMap(unit);
					unit.setRow(c);
					unit.setCol(r);
					map2[r][c].setHasUnit(true);
					r += 4;
				}
			}
		}

	}

	private void placeP2M1() {

		if (!UnitSelection.isHorde()) {

			int r = 21;
			int c = 21;
			for (Unit unit : Player2.getUnitsInstance()) {

				if (r < 21 && c < 21) {
					c = 19;
					r = 19;
					map1[r][c].setUnitInMap(unit);
					map1[r][c].getUnit().setRow(c);
					map1[r][c].getUnit().setCol(r);
					map1[r][c].setHasUnit(true);
				} else if (c >= 13) {
					map1[r][c].setUnitInMap(unit);
					unit.setRow(c);
					unit.setCol(r);
					map1[r][c].setHasUnit(true);
					c -= 4;
				} else {
					c = 21;
					r -= 4;
					map1[r][c].setUnitInMap(unit);
					map1[r][c].getUnit().setRow(c);
					map1[r][c].getUnit().setCol(r);
					map1[r][c].setHasUnit(true);
					r -= 4;
				}
			}
		} else if (UnitSelection.isHorde()) {

			map1[11][22].setUnitInMap(Player2.getHordeUnits().get(0));
			map1[11][22].getUnit().setRow(22);
			map1[11][22].getUnit().setCol(11);
			map1[11][22].setHasUnit(true);
			map1[9][22].setUnitInMap(Player2.getHordeUnits().get(1));
			map1[9][22].getUnit().setRow(22);
			map1[9][22].getUnit().setCol(9);
			map1[9][22].setHasUnit(true);
			map1[13][22].setUnitInMap(Player2.getHordeUnits().get(2));
			map1[13][22].getUnit().setRow(22);
			map1[13][22].getUnit().setCol(13);
			map1[13][22].setHasUnit(true);

			int c = 21;
			int r = 7;
			int p = 4;

			for (int i = 3; i < Player2.getHordeUnits().size(); i++) {
				// Player2.getHordeUnits().get(i).setTeam(2);
				if (r < 23) {
					map1[r][c].setUnitInMap(Player2.getHordeUnits().get(i));
					Player2.getHordeUnits().get(i).setRow(c);
					Player2.getHordeUnits().get(i).setCol(r);
					map1[r][c].setHasUnit(true);
					r++;
				}

			}

		}

	}

	private void placeP2M2() {

		if (!UnitSelection.isHorde()) {
			int r = 21;
			int c = 21;

			for (Unit unit : Player2.getUnitsInstance()) {
				unit.setTeam(2);

				if (r < 21 && c < 21) {
					c = 19;
					r = 19;
					map2[r][c].setUnitInMap(unit);
					map2[r][c].getUnit().setRow(c);
					map2[r][c].getUnit().setCol(r);
					map2[r][c].setHasUnit(true);
				} else if (c >= 13) {
					map2[r][c].setUnitInMap(unit);
					unit.setRow(c);
					unit.setCol(r);
					map2[r][c].setHasUnit(true);
					c -= 4;
				} else {
					c = 21;
					r -= 4;
					map2[r][c].setUnitInMap(unit);
					map2[r][c].getUnit().setRow(c);
					map2[r][c].getUnit().setCol(r);
					map2[r][c].setHasUnit(true);
					r -= 4;
				}
			}
		} else if (UnitSelection.isHorde()) {

			map2[11][22].setUnitInMap(Player2.getHordeUnits().get(0));
			map2[11][22].getUnit().setRow(22);
			map2[11][22].getUnit().setCol(11);
			map2[11][22].setHasUnit(true);
			map2[9][22].setUnitInMap(Player2.getHordeUnits().get(1));
			map2[9][22].getUnit().setRow(22);
			map2[9][22].getUnit().setCol(9);
			map2[9][22].setHasUnit(true);
			map2[13][22].setUnitInMap(Player2.getHordeUnits().get(2));
			map2[13][22].getUnit().setRow(22);
			map2[13][22].getUnit().setCol(13);
			map2[13][22].setHasUnit(true);

			int c = 21;
			int r = 3;
			int p = 4;

			for (int i = 3; i < Player2.getHordeUnits().size(); i++) {
				// Player2.getHordeUnits().get(i).setTeam(2);
				if (r < 23) {
					map2[r][c].setUnitInMap(Player2.getHordeUnits().get(i));
					Player2.getHordeUnits().get(i).setRow(c);
					Player2.getHordeUnits().get(i).setCol(r);
					map2[r][c].setHasUnit(true);
					r += 2;
				} else {
					c = 20;
					map2[p][c].setUnitInMap(Player2.getHordeUnits().get(i));
					Player2.getHordeUnits().get(i).setRow(c);
					Player2.getHordeUnits().get(i).setCol(p);
					map2[p][c].setHasUnit(true);
					p += 2;
				}

			}
		}

	}

	private void fillMap1() {
		// TODO Auto-generated method stub
		for (int r = 0; r < SIZE; r++) {
			for (int c = 0; c < SIZE; c++) {
				if (r < 3 || r > 22 || c < 3 || c > 22) {
					map1[r][c] = new Room(true, false, false, new no());
				} else {
					map1[r][c] = new Room(false, false, false, new no());

				}
			}

		}
	}

	private void fillMap2() {
		// TODO Auto-generated method stub
		for (int r = 0; r < SIZE; r++) {
			for (int c = 0; c < SIZE; c++) {
				if (r < 3 || r > 22 || c < 3 || c > 22) {
					map2[r][c] = new Room(true, false, false, new no());
				} else {
					map2[r][c] = new Room(false, false, false, new no());

				}
			}

		}
	}

	public void makeMap1() {
		fillMap1();
		placeP1M1();
		placeP2M1();
		setWater();
		placeTreesM1();
		placeChestsM1();

	}

	private void placeChestsM1() {
		// TODO Auto-generated method stub
		int randyInt = randy.nextInt(4) + 3;

		for (int i = 0; i < randyInt; i++) {

			int randyX = randy.nextInt(19) + 3;
			int randyY = randy.nextInt(19) + 3;

			if (!map1[randyX][randyY].getHasUnit()
					&& !map1[randyX][randyY].isFlag()
					&& !map1[randyX][randyY].isObstruction()
					&& !map1[randyX][randyY].isWater()
					&& (randyX < 22 && randyY < 22 && randyX > 2 && randyY > 2)) {
				map1[randyX][randyY].setChest(true);

			} else {

			}
		}
	}

	private void setWater() {

		map1[2][13].setObstruction(true);
		map1[3][13].setObstruction(true);
		map1[4][13].setObstruction(true);
		map1[5][13].setObstruction(true);
		map1[6][13].setObstruction(true);
		map1[7][13].setObstruction(true);
		map1[8][13].setObstruction(true);

		map1[3][14].setObstruction(true);
		map1[4][14].setObstruction(true);
		map1[5][14].setObstruction(true);
		map1[6][14].setObstruction(true);
		map1[7][14].setObstruction(true);
		map1[8][14].setObstruction(true);

		map1[3][15].setObstruction(true);
		map1[4][15].setObstruction(true);
		map1[5][15].setObstruction(true);
		map1[6][15].setObstruction(true);
		map1[7][15].setObstruction(true);
		map1[8][15].setObstruction(true);

		map1[2][13].setWater(true);
		map1[3][13].setWater(true);
		map1[4][13].setWater(true);
		map1[5][13].setWater(true);
		map1[6][13].setWater(true);
		map1[7][13].setWater(true);
		map1[8][13].setWater(true);

		map1[3][14].setWater(true);
		map1[4][14].setWater(true);
		map1[5][14].setWater(true);
		map1[6][14].setWater(true);
		map1[7][14].setWater(true);
		map1[8][14].setWater(true);

		map1[6][15].setWater(true);
		map1[7][15].setWater(true);
		map1[8][15].setWater(true);

		map1[3][16].setObstruction(true);
		map1[4][16].setObstruction(true);
		map1[5][16].setObstruction(true);
		map1[6][16].setObstruction(true);
		map1[7][16].setObstruction(true);

	}

	public void makeMap2() {
		fillMap2();
		placeP1M2();
		placeP2M2();
		placeRocks();
		placeChestsM2();

	}

	private void placeChestsM2() {
		// TODO Auto-generated method stub
		int randyInt = randy.nextInt(4) + 3;

		for (int i = 0; i < randyInt; i++) {

			int randyX = randy.nextInt(19) + 3;
			int randyY = randy.nextInt(19) + 3;

			if (!map2[randyX][randyY].getHasUnit()
					&& !map2[randyX][randyY].isFlag()
					&& !map2[randyX][randyY].isObstruction()
					&& !map2[randyX][randyY].isWater()
					&& (randyX < 22 && randyY < 22 && randyX > 2 && randyY > 2)) {
				map2[randyX][randyY].setChest(true);

			} else {

			}
		}
	}

	private void placeRocks() {

		int randyInt = randy.nextInt(15) + 10;

		for (int i = 0; i < randyInt; i++) {

			int randyX = randy.nextInt(19) + 3;
			int randyY = randy.nextInt(19) + 3;

			if (!map2[randyX][randyY].getHasUnit()
					&& !map2[randyX][randyY].isFlag()
					&& !map2[randyX][randyY].isWater()) {
				map2[randyX][randyY].setObstruction(true);
			}
		}

	}

	public Room[][] getMap1() {
		return map1;
	}

	public Room[][] getMap2() {
		return map2;
	}

	private void placeTreesM1() {

		int randyInt = randy.nextInt(15) + 10;

		for (int i = 0; i < randyInt; i++) {

			int randyX = randy.nextInt(19) + 3;
			int randyY = randy.nextInt(19) + 3;

			if (!map1[randyX][randyY].getHasUnit()
					&& !map1[randyX][randyY].isFlag()
					&& !map1[randyX][randyY].isWater()) {
				map1[randyX][randyY].setObstruction(true);
			}
		}

	}

	/**
	 * @return the p1Units
	 */
	public ArrayList<Unit> getP1Units() {
		return p1Units;
	}

	/**
	 * @param p1Units
	 *            the p1Units to set
	 */
	public void setP1Units(ArrayList<Unit> p1Units) {
		this.p1Units = p1Units;
	}

	/**
	 * @return the p2Units
	 */
	public ArrayList<Unit> getP2Units() {
		return p2Units;
	}

	/**
	 * @param p2Units
	 *            the p2Units to set
	 */
	public void setP2Units(ArrayList<Unit> p2Units) {
		this.p2Units = p2Units;
	}

}
