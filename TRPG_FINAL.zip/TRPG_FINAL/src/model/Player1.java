package model;

import java.io.Serializable;
import java.util.ArrayList;

import units.Unit;

/*
 * Singleton class keeps track of the players List of Items and list of Units
 */
public class Player1 implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1733063834043149223L;
	private static ArrayList<Unit> units;
	private static int potionQuantity = 3;
	private static int attackQuantity = 3;
	private static int speedQuantity = 3;
	private static Unit captain;
	private static int aliveUnits;

	private Player1() {
	}

	public static ArrayList<Unit> getUnitsInstance() {
		if (units == null) {
			units = new ArrayList<Unit>();
			// setUnits();
		}
		return units;
	}

	public static void addUnit(Unit unit) {
		if (units == null) {
			units = new ArrayList<Unit>();
		}
		units.add(unit);
		// System.out.println(unit.toString());
	}

	public static int getPotionQuantity() {
		return potionQuantity;
	}

	public static void setPotionQuantity(int potionQuantity) {
		Player1.potionQuantity = potionQuantity;
	}

	/**
	 * @return the attackQuantity
	 */
	public static int getAttackQuantity() {
		return attackQuantity;
	}

	/**
	 * @param attackQuantity
	 *            the attackQuantity to set
	 */
	public static void setAttackQuantity(int attackQuantity) {
		Player1.attackQuantity = attackQuantity;
	}

	/**
	 * @return the speedQuantity
	 */
	public static int getSpeedQuantity() {
		return speedQuantity;
	}

	/**
	 * @param speedQuantity
	 *            the speedQuantity to set
	 */
	public static void setSpeedQuantity(int speedQuantity) {
		Player1.speedQuantity = speedQuantity;
	}

	/**
	 * @return the captain
	 */
	public static Unit getCaptain() {
		return captain;
	}

	/**
	 * @param captain
	 *            the captain to set
	 */
	public static void setCaptain() {
		captain = units.get(0);

	}

	public static int getUnitsLeftNumber() {
		aliveUnits = units.size() - 1;
		for (Unit unit : units) {
			if (!unit.isAlive()) {
				aliveUnits--;
			}
		}
		return aliveUnits;
	}
	
	public static void reset(){
		units = new ArrayList<Unit>();
		
	}
}
