package model;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import units.Unit;

public class SaveGame 
{
	private String username;
	private ArrayList<Unit> player1Units = new ArrayList<Unit>();
	/**
	 * The Constructor takes the user's name to use it as the filename for
	 * User's name. 
	 * @param username
	 */
	public SaveGame(String username)
	{
		this.username = username;
		
		for(Unit unit : Player1.getUnitsInstance())
			player1Units.add(unit);
		System.out.println(player1Units.toString());
		saveGame();
	}//END SaveGame Constructor
	
	/**
	 * This method is what saves the User's game.
	 */
	private void saveGame()
	{
		try 
		{
			System.out.println(username + " was saved!");
			FileOutputStream outStream = new FileOutputStream(username);
			ObjectOutputStream outObject = new ObjectOutputStream(outStream);
			outObject.writeObject(player1Units);
			outObject.close();
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}//ENDS saveGame method
}//END SaveGame Class
