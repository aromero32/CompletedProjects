package model;

import units.Unit;
import units.no;

public class Room {
	// private BufferedImage image;

	private boolean canMove, canAttack;
	private boolean obstruction; // nothing can move there
	private boolean canDamage; // traps
	private boolean hasUnit; // has a unit
	private boolean isSelected; // gets the room that was clicked on (first
								// click)
	private boolean isFlag; // (used in CTF) sets the flags
	private boolean deadGuy;
	private Unit unit; // unit in the room
	private boolean chest;
	private boolean water;

	public Room(boolean obstruction, boolean hasUnit, boolean damage, Unit unit) {
		this.obstruction = obstruction;
		this.canDamage = damage;
		this.hasUnit = hasUnit;
		isSelected = false;
		setDeadGuy(false);
		this.unit = unit;
		canMove = false;
		setFlag(false);
		setCanAttack(false);
		setChest(false);
		setWater(false);
	}

	/*
	 * returns if a unit is allowed to move in map room
	 */
	public boolean getCanMove() {
		if (hasUnit == true || obstruction == true) {
			canMove = false;
			return canMove;
		} else {
			return canMove;
		}
	}

	public void setCanMove(boolean canMove) {
		this.canMove = canMove;
	}

	public void setObstruction(boolean obstruction) {
		this.obstruction = obstruction;
	}

	public boolean isObstruction() {
		return obstruction;
	}

	/* used for damage objects */
	public boolean getDamage() {
		return canDamage;
	}

	public void setCanDamage(boolean canDamage) {
		this.canDamage = canDamage;
	}

	/* used for seeing or setting a unit */
	public boolean getHasUnit() {
		return hasUnit;
	}

	public void setUnitInMap(Unit unit) {
		this.unit = unit;
	}// hard-coding it into the map

	public void setHasUnit(boolean t) {
		hasUnit = t;
	}

	public Unit getUnit() {
		return unit;
	}

	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}

	public boolean getSelected() {
		return isSelected;
	}

	public void removeUnit() {
		unit = new no();

	}

	public boolean canAttack() {
		return canAttack;
	}

	public void setCanAttack(boolean canAttack) {
		this.canAttack = canAttack;
	}

	/**
	 * @return the isFlag
	 */
	public boolean isFlag() {
		return isFlag;
	}

	/**
	 * @param isFlag
	 *            the isFlag to set
	 */
	public void setFlag(boolean isFlag) {
		this.isFlag = isFlag;
	}

	/**
	 * @return the deadGuy
	 */
	public boolean isDeadGuy() {
		return deadGuy;
	}

	/**
	 * @param deadGuy
	 *            the deadGuy to set
	 */
	public void setDeadGuy(boolean deadGuy) {
		this.deadGuy = deadGuy;
	}

	/**
	 * @return the chest
	 */
	public boolean isChest() {
		return chest;
	}

	/**
	 * @param chest
	 *            the chest to set
	 */
	public void setChest(boolean chest) {
		this.chest = chest;
	}

	/**
	 * @return the water
	 */
	public boolean isWater() {
		return water;
	}

	/**
	 * @param water the water to set
	 */
	public void setWater(boolean water) {
		this.water = water;
	}
}
