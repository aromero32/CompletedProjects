package units;

import java.awt.Image;

public class no extends Unit {

	public no() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		return "no";
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "no";
	}

	@Override
	public int getCurrentHealth() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setCurrentHealth(int damage) {
		// TODO Auto-generated method stub

	}

	@Override
	public int getMaxHealth() {
		// TODO Auto-generated method stub
		return 0;
	}

	// @Override
	// public int getAttack() {
	// // TODO Auto-generated method stub
	// return 0;
	// }

	@Override
	public int getAttackRange() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Image getImageF() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Image getImage() {
		// TODO Auto-generated method stub
		return null;
	}

	// @Override
	// public int getMovementSpeed() {
	// // TODO Auto-generated method stub
	// return 0;
	// }

	// @Override
	// public void setMovementSpeed(int ms) {
	// // TODO Auto-generated method stub
	//
	// }
	//
	// @Override
	// public void setAttackDamage(int attackDamage) {
	// // TODO Auto-generated method stub
	//
	// }

}
