package units;

import java.awt.Image;

public abstract class Unit {

	private int row, col, team, movementSpeed, attackDamage, currentHealth;
	private boolean moving, attacking, canAttack, canMove, mL, mR, tookTurn,
			isAlive, isCap;
	private String place;

	public Unit() {
		setAlive(true);
		setPlace("");
		this.moving = false;
		this.attacking = false;
		canMove = true;
		canAttack = true;
		team = 0;
		tookTurn = false;
		movementSpeed = 0;
		attackDamage = 0;
		isCap = false;
	}

	public boolean isMoving() {
		return moving;
	}

	public void setMoving(boolean moving) {
		this.moving = moving;
	}

	public boolean isAttacking() {
		return attacking;
	}

	public void setAttacking(boolean attacking) {
		this.attacking = attacking;
	}

	public boolean canAttack() {
		return canAttack;
	}

	public void setCanAttack(boolean canAttack) {
		this.canAttack = canAttack;
	}

	public boolean canMove() {
		return canMove;
	}

	public void setCanMove(boolean canMove) {
		this.canMove = canMove;
	}

	public abstract int getMaxHealth();

	// public int getCurrentHealth() {
	// return currentHealth;
	// }
	//
	// public void setCurrentHealth(int damage) {
	// currentHealth = currentHealth - damage;
	// if (currentHealth <= 0) {
	// setAlive(false);
	// }
	// }

	// public int getMaxHealth() {
	// return maxHealth;
	// }

	public abstract int getAttackRange();

	public abstract Image getImageF();

	public abstract Image getImage();

	public void setMovementSpeed(int ms) {
		this.movementSpeed = ms;
	}

	public void setAttackDamage(int attackDamage) {
		this.attackDamage = attackDamage;
	}

	public int getRow() {
		return row;
	}

	public int getCol() {
		return col;
	}

	public void setRow(int row) {
		this.row = row;
	}

	public void setCol(int col) {
		this.col = col;
	}

	public abstract String getTitle();

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return getTitle() + "    " + "HP:   " + getCurrentHealth() + "        "
				+ "ATK:   " + getAttackDamage() + "   " + "SPD:   "
				+ getMovementSpeed();
	}

	public boolean getML() {
		return mL;
	}

	public void setML(boolean l) {
		mL = l;
	}

	public boolean getMR() {
		return mR;
	}

	public void setMR(boolean r) {
		mR = r;
	}

	public int getTeam() {
		return team;
	}

	public void setTeam(int team) {
		this.team = team;
	}

	public boolean isTookTurn() {
		return tookTurn;
	}

	public void setTookTurn(boolean tookTurn) {
		this.tookTurn = tookTurn;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public boolean isAlive() {
		return isAlive;
	}

	public void setAlive(boolean isAlive) {
		this.isAlive = isAlive;
	}

	public int getAttackDamage() {
		return attackDamage;
	}

	public int getMovementSpeed() {
		return movementSpeed;
	}

	/**
	 * @return the currentHealth
	 */
	public int getCurrentHealth() {
		return currentHealth;
	}

	/**
	 * @param currentHealth
	 *            the currentHealth to set
	 */
	public void setCurrentHealth(int damage) {
		currentHealth = currentHealth - damage;
		if (currentHealth <= 0) {
			setAlive(false);
			// the unit has died
		}
	}

	/**
	 * @return the isCap
	 */
	public boolean isCap() {
		return isCap;
	}

	/**
	 * @param isCap
	 *            the isCap to set
	 */
	public void setCap(boolean isCap) {
		this.isCap = isCap;
	}

	// public void setMaxHealth(int maxHealth) {
	// this.maxHealth = maxHealth;
	// currentHealth = maxHealth;
	//
	// }
}
