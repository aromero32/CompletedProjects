package units;

import java.awt.Image;
import java.io.File;
import java.io.Serializable;

import javax.imageio.ImageIO;

public class Troll extends Unit implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1524508767936127969L;
	private String title = "";
	// private int movementSpeed;
	private int maxHealth;
	// private int currentHealth;
	// private int attack;
	private int attackRange;
	private Image troll;
	private Image trollF;

	public Troll() {
		try {
			troll = ImageIO.read(new File("src/UnitImages/troll.png"));
			trollF = ImageIO.read(new File("src/UnitImages/trollF.png"));

		} catch (Exception e) {
			e.printStackTrace();// TODO: handle exception
		}

		title = "Troll";

		setMovementSpeed(1);
		setAttackDamage(80);
		// movementSpeed = 3;
		maxHealth = 250;
		setCurrentHealth(-3);
		// attack = 30;
		attackRange = 1;
	}

	@Override
	public String getTitle() {
		return title;
	}

	// @Override
	// public int getCurrentHealth() {
	// return currentHealth;
	// }

	// @Override
	// public void setCurrentHealth(int damage) {
	// currentHealth = currentHealth - damage;
	// if (currentHealth <= 0) {
	// setAlive(false);
	// // the unit has died
	// }
	// }

	// @Override
	// public int getAttack() {
	// return attack;
	// }

	@Override
	public int getAttackRange() {
		return attackRange;
	}

	// @Override
	// public int getMovementSpeed() {
	// return movementSpeed;
	// }

	public int getRow() {
		return super.getRow();
	}

	public int getCol() {
		return super.getCol();
	}

	public void setRow(int row) {
		super.setRow(row);
	}

	public void setCol(int col) {
		super.setCol(col);
	}

	@Override
	public int getMaxHealth() {
		return maxHealth;
	}

	@Override
	public Image getImageF() {
		// TODO Auto-generated method stub
		return trollF;
	}

	@Override
	public Image getImage() {
		// TODO Auto-generated method stub
		return troll;
	}

	// @Override
	// public void setMovementSpeed(int ms) {
	// // TODO Auto-generated method stub
	//
	// }
	//
	// @Override
	// public void setAttackDamage(int attackDamage) {
	// // TODO Auto-generated method stub
	//
	// }

}// END class Troll
