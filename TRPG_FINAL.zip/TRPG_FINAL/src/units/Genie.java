package units;

import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;

import javax.imageio.ImageIO;

public class Genie extends Unit implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5696720459749954469L;
	private String title;
	// private int movementSpeed;
	private int maxHealth;
	// private int currentHealth;
	// private int attack;
	private int attackRange;
	private Image genie;
	private Image genieF;

	public Genie() {

		try {
			genie = ImageIO.read(new File("src/UnitImages/pixelGenieS.png"));
			genieF = ImageIO.read(new File("src/UnitImages/pixelGenieSF.png"));
		}

		catch (IOException e) {
			e.printStackTrace();
		}

		title = "Genie";
		super.setMovementSpeed(3);
		super.setAttackDamage(30);
		maxHealth = 100;
		// currentHealth = 100;
		setCurrentHealth(-1);
		attackRange = 2;
	}

	@Override
	public Image getImage() {
		return genie;
	}

	@Override
	public Image getImageF() {
		return genieF;
	}

	@Override
	public String getTitle() {
		return title;
	}

	// @Override
	// public int getCurrentHealth() {
	// return currentHealth;
	// }

	// @Override
	// public void setCurrentHealth(int damage) {
	// currentHealth = currentHealth - damage;
	//
	// }

	// @Override
	// public int getAttack() {
	// return attack;
	// }

	@Override
	public int getAttackRange() {
		return attackRange;
	}

	// @Override
	// public int getMovementSpeed() {
	// return movementSpeed;
	// }

	public int getRow() {
		return super.getRow();
	}

	public int getCol() {
		return super.getCol();
	}

	public void setRow(int row) {
		super.setRow(row);
	}

	public void setCol(int col) {
		super.setCol(col);
	}

	@Override
	public int getMaxHealth() {
		return maxHealth;
	}

	// @Override
	// public void setMovementSpeed(int ms) {
	// // TODO Auto-generated method stub
	//
	// }
	//
	// @Override
	// public void setAttackDamage(int attackDamage) {
	// // TODO Auto-generated method stub
	//
	// }

}
