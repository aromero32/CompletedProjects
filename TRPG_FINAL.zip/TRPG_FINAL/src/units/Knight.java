package units;

import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;

import javax.imageio.ImageIO;

public class Knight extends Unit implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3799735089591361637L;
	private String title = "";
	// private int movementSpeed;
	private int maxHealth;
	// private int currentHealth;
	// private int attack;
	private int attackRange;
	private Image knight;
	private Image knightF;

	public Knight() {
		try {

			knight = ImageIO.read(new File("src/UnitImages/pixelKnight.png"));
			knightF = ImageIO.read(new File("src/UnitImages/pixelKnightF.png"));
		}

		catch (IOException e) {
			e.printStackTrace();
		}

		title = "Knight";
		super.setMovementSpeed(2);
		super.setAttackDamage(40);

		// movementSpeed = 2;
		maxHealth = 300;
		// currentHealth = 300;
		setCurrentHealth(-3);
		// attack = 40;
		attackRange = 1;
	}

	@Override
	public String getTitle() {
		return title;
	}

	// @Override
	// public int getCurrentHealth() {
	// return currentHealth;
	// }

	// @Override
	// public void setCurrentHealth(int damage) {
	// currentHealth = currentHealth - damage;
	// if (currentHealth <= 0) {
	// setAlive(false);
	// // the unit has died
	// }
	// }

	// @Override
	// public int getAttack() {
	// return attack;
	// }
	//
	// @Override
	// public int getMovementSpeed() {
	// return movementSpeed;
	// }

	public int getRow() {
		return super.getRow();
	}

	public int getCol() {
		return super.getCol();
	}

	public void setRow(int row) {
		super.setRow(row);
	}

	public void setCol(int col) {
		super.setCol(col);
	}

	@Override
	public int getMaxHealth() {
		return maxHealth;
	}

	@Override
	public int getAttackRange() {
		return attackRange;
	}

	@Override
	public Image getImageF() {
		// TODO Auto-generated method stub
		return knightF;
	}

	@Override
	public Image getImage() {
		// TODO Auto-generated method stub
		return knight;
	}

	// @Override
	// public void setMovementSpeed(int ms) {
	// // TODO Auto-generated method stub
	//
	// }
	//
	// @Override
	// public void setAttackDamage(int attackDamage) {
	// // TODO Auto-generated method stub
	//
	// }

}// END class Knight
