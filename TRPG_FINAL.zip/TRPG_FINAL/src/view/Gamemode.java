package view;

import javax.swing.JPanel;

public abstract class Gamemode extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2437837086684795675L;

}
