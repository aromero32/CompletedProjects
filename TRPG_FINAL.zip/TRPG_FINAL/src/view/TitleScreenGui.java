package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import units.Unit;

@SuppressWarnings("serial")
public class TitleScreenGui extends JFrame {

	private JPanel buttonPanel;
	private JPanel textPanel;
	private JPanel bottomPanel;

	private JButton startGameButton;
	private JButton loadGameButton;
	private JButton optionsButton;
	private JButton quitGameButton;
	private JButton musicButton;

	JPanel backPanel;
	private JPanel gamePanel;
	UnitSelection unitSelection = new UnitSelection(this);

	private ArrayList<Unit> userUnits;// = new ArrayList<Unit>();

	public TitleScreenGui() {
		layoutGUI();
		registerListeners();
	}

	/**
	 * layoutGUI() - creates the GUI for NetPaint
	 */
	private void layoutGUI() {
		backPanel = new JPanel();
		gamePanel = new JPanel();
		gamePanel.setLayout(new BorderLayout());
		gamePanel.setBackground(Color.BLACK);
		backPanel.setLayout(new BorderLayout());

		JPanel titlePanel = new JPanel();
		titlePanel.setLayout(new BorderLayout());
		titlePanel.setBackground(Color.BLACK);
		ImagePanel titleImage = new ImagePanel("src/images/FWT.png",
				Color.BLACK);
		ImagePanel extraTitleImage = new ImagePanel("src/images/swords.png",
				Color.BLACK);
		ImagePanel extraTitleImage2 = new ImagePanel("src/images/swords.png",
				Color.BLACK);

		Dimension dimension = new Dimension(500, 100);
		titleImage.setPreferredSize(dimension);
		dimension = new Dimension(90, 100);
		extraTitleImage.setPreferredSize(dimension);
		extraTitleImage2.setPreferredSize(dimension);
		titlePanel.add(titleImage, BorderLayout.CENTER);
		titlePanel.add(extraTitleImage2, BorderLayout.WEST);
		titlePanel.add(extraTitleImage, BorderLayout.EAST);

		buttonPanel = new JPanel();
		buttonPanel.setLayout(new BorderLayout());

		JPanel gBPanel = new JPanel();
		gBPanel.setLayout(new BoxLayout(gBPanel, BoxLayout.Y_AXIS));
		gBPanel.setBackground(Color.BLACK);

		buttonPanel.add(gBPanel, BorderLayout.NORTH);
		buttonPanel.setBackground(Color.BLACK);

		startGameButton = new JButton("Start Game");
		startGameButton.setOpaque(true);
		startGameButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		gBPanel.add(startGameButton);

		loadGameButton = new JButton();
		loadGameButton.setText("Load Game");
		loadGameButton.setOpaque(true);
		loadGameButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		gBPanel.add(loadGameButton);

		optionsButton = new JButton("   Options    ");
		optionsButton.setOpaque(true);
		optionsButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		gBPanel.add(optionsButton);

		quitGameButton = new JButton("  Quit Game");
		quitGameButton.setOpaque(true);
		quitGameButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		gBPanel.add(quitGameButton);

		JPanel otherPanel = new JPanel();
		otherPanel.setBackground(Color.BLACK);

		ImagePanel castle = new ImagePanel("src/images/sas.png", Color.BLACK);
		ImagePanel castle2 = new ImagePanel("src/images/sas.png", Color.BLACK);
		ImagePanel castle3 = new ImagePanel("src/images/castle.png",
				Color.BLACK);

		dimension = new Dimension(300, 250);
		castle3.setPreferredSize(dimension);
		dimension = new Dimension(90, 90);
		castle2.setPreferredSize(dimension);
		castle.setPreferredSize(dimension);
		otherPanel.add(castle2, BorderLayout.WEST);
		otherPanel.add(castle3, BorderLayout.CENTER);
		otherPanel.add(castle, BorderLayout.EAST);

		buttonPanel.add(otherPanel);

		Icon icon = new ImageIcon("src/images/note.png");
		musicButton = new JButton(icon);
		musicButton.setSize(10, 10);
		dimension = new Dimension(32, 32);
		musicButton.setPreferredSize(dimension);

		textPanel = new JPanel();
		textPanel.setBackground(Color.black);
		Label hello = new Label("HELLO THERE");
		hello.setBackground(Color.black);
		hello.setForeground(Color.WHITE);
		textPanel.add(hello);

		bottomPanel = new JPanel();
		bottomPanel.setBackground(Color.BLACK);
		bottomPanel.setLayout(new BorderLayout());
		bottomPanel.add(textPanel, BorderLayout.CENTER);
		bottomPanel.add(musicButton, BorderLayout.WEST);

		gamePanel.add(titlePanel, BorderLayout.NORTH);
		gamePanel.add(buttonPanel, BorderLayout.CENTER);
		gamePanel.add(bottomPanel, BorderLayout.SOUTH);
		backPanel.add(gamePanel, BorderLayout.CENTER);
		this.add(backPanel);
		this.setVisible(true);
		setLocation(600, 250);
		this.setSize(640, 600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}// END layoutGUI

	/**
	 * registerListeners() - registers all of the action listeners for the
	 * buttons and mouse
	 */
	private void registerListeners() {
		startGameButton.addActionListener(new StartGameListener());
		loadGameButton.addActionListener(new LoadGameListener());
		optionsButton.addActionListener(new OptionsListener());
		quitGameButton.addActionListener(new QuitGameListener());
		musicButton.addActionListener(new MusicListener());

	}// END registerListeners

	private class StartGameListener implements ActionListener {

		public void actionPerformed(ActionEvent arg0) {
			// backPanel = new JPanel();
			System.out.println("Welcome, you are now ready to start the game.");

			backPanel.remove(gamePanel);
			backPanel.add(unitSelection, BorderLayout.CENTER);
			setVisible(true);
			setLocation(300, 100);
			setSize(1000, 700);
		}

	}// END StartGameListener

	/**
	 * This method loads the player's game.
	 * 
	 */
	private class LoadGameListener implements ActionListener {

		@SuppressWarnings("unchecked")
		public void actionPerformed(ActionEvent arg0) {
			System.out.println("Welcome, your game has been loaded.");
			userUnits = new ArrayList<Unit>();
			try {
				FileInputStream inStream = new FileInputStream("q.dat");
				ObjectInputStream inObject = new ObjectInputStream(inStream);
				// LOAD THE UNITS HERE
				userUnits = (ArrayList<Unit>) inObject.readObject();
				inObject.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println(userUnits.toString());
		}

	}// END LoadGameListener

	private class OptionsListener implements ActionListener {

		public void actionPerformed(ActionEvent arg0) {
			System.out
					.println("Welcome, how do you want to configure your game options?");

		}

	}// END OptionsListener

	private class QuitGameListener implements ActionListener {

		public void actionPerformed(ActionEvent arg0) {
			System.out.println("Goodbye, see you again soon!");

			int answer = JOptionPane.showConfirmDialog(null, "Save Data?",
					"Save Data", JOptionPane.YES_NO_OPTION);

			if (answer == JOptionPane.YES_OPTION)
				saveGame();

		}

	}// END QuitGameListener

	private class MusicListener implements ActionListener {

		public void actionPerformed(ActionEvent arg0) {
			System.out.println("Music has been muted!");

		}

	}// END MusicListener

	/**
	 * This method saves the game
	 */
	public void saveGame() {
		try {
			FileOutputStream outStream = new FileOutputStream("game.data");
			ObjectOutputStream outObject = new ObjectOutputStream(outStream);
			outObject.writeObject(outObject);
			outObject.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}// END saveGame

	public static void main(String[] args) {
		new TitleScreenGui();
	}

}
