package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import model.Player1;
import model.SelectedList;
import model.UnitCollection;
import units.Archer;
import units.Captain;
import units.Genie;
import units.Knight;
import units.Mage;
import units.Ranger;
import units.Theif;
import units.Unit;
import units.Warrior;
import units.no;

@SuppressWarnings("serial")
public class UnitSelection extends JPanel {
	private JPanel unitPanel, selectedJPanel, characterPanel, mapPanel;
	private UnitCollection units;
	private SelectedList userSelect;
	private ViewCharacter charater;
	private Unit unit;
	private JList<Unit> usersUnits;
	@SuppressWarnings("unused")
	private Unit selectedUnit;

	@SuppressWarnings("unused")
	private int count;

	private JTextArea situationDescription;

	private Unit newUnit;

	private JTable unitTable;
	private JButton removeButton = new JButton("Remove Unit");
	private JButton startButton = new JButton("Start Game");
	private JButton addButton = new JButton("Add Unit");
	private JLabel label;
	private MapPanel gameStart;
	private TitleScreenGui titleScreen;

	private JRadioButton map1;
	private JRadioButton map2;
	private ButtonGroup mapButtonGroup;
	private JPanel mapButtonPanel;

	private JRadioButton situation1;
	private JRadioButton situation2;
	private JRadioButton situation3;
	private ButtonGroup situationButtonGroup;
	private JPanel situationButtonPanel;

	private ViewMap map;
	private String mapName;
	private String gameType;

	private static boolean horde;

	public UnitSelection(TitleScreenGui mainframe) {
		mapName = "";
		titleScreen = mainframe;
		addUnits();
		setUpButtons();
		layoutGUI();
		registerListeners();
		setHorde(false);

	}// END UnitSelection Constructor

	private void setUpButtons() {

		map1 = new JRadioButton("Meadow");
		map2 = new JRadioButton("Wasteland");
		map1.setBackground(Color.BLACK);
		map2.setBackground(Color.BLACK);

		mapButtonGroup = new ButtonGroup();

		mapButtonGroup.add(map1);
		mapButtonGroup.add(map2);

		mapButtonPanel = new JPanel();

		mapButtonPanel.add(map1);
		mapButtonPanel.add(map2);

		mapButtonPanel.setBackground(Color.black);

		map1.setForeground(Color.white);
		map2.setForeground(Color.white);

		situation1 = new JRadioButton("TDM");
		situation2 = new JRadioButton("KotH");
		situation3 = new JRadioButton("Horde");

		situationButtonGroup = new ButtonGroup();

		situationButtonGroup.add(situation1);
		situationButtonGroup.add(situation2);
		situationButtonGroup.add(situation3);

		situationButtonPanel = new JPanel();

		situationButtonPanel.add(situation1);
		situationButtonPanel.add(situation2);
		situationButtonPanel.add(situation3);

		situationButtonPanel.setBackground(Color.black);
		situation1.setForeground(Color.white);
		situation1.setBackground(Color.BLACK);
		situation2.setForeground(Color.white);
		situation2.setBackground(Color.BLACK);
		situation3.setForeground(Color.white);
		situation3.setBackground(Color.BLACK);

	}

	public void layoutGUI() {

		situationDescription = new JTextArea();
		situationDescription.setBackground(Color.BLACK);
		situationDescription.setForeground(Color.white);

		setLayout(null); // Set layout to null. I manually set the panels in.

		// Sets the unitTable of Units to be selected
		unitTable = new JTable(units);
		unitTable.setRowSorter(new TableRowSorter<TableModel>(unitTable
				.getModel()));
		unitTable.setBackground(Color.BLACK);
		unitTable.setForeground(Color.white);

		// Makes the list of units selected by the User.
		userSelect = new SelectedList();
		usersUnits = new JList<Unit>(userSelect);
		usersUnits.setBackground(Color.BLACK);
		usersUnits.setForeground(Color.white);
		usersUnits.setPreferredSize(new Dimension(100, 200));

		// The Table is added to the JPanel to be added to frame.
		unitPanel = new JPanel();
		unitPanel.setBackground(Color.BLACK);
		unitPanel.setForeground(Color.white);
		unitPanel.setLayout(new BorderLayout());
		unitPanel.add(unitTable, BorderLayout.CENTER);
		unitPanel.add(new Label("Selected your units"), BorderLayout.NORTH);
		unitPanel.setBounds(0, 0, 600, 150); // set location and size of panel

		// The selected units are added to the panel along with the remove
		// buttons.
		selectedJPanel = new JPanel();
		selectedJPanel.setSize(100, 200);
		selectedJPanel.setBackground(Color.BLACK);
		selectedJPanel.setForeground(Color.white);
		selectedJPanel.setLayout(new BorderLayout());
		label = new JLabel("Your current units");
		label.setSize(20, 10);
		label.setBackground(Color.BLACK);
		label.setForeground(Color.WHITE);
		JScrollPane scroller = new JScrollPane(usersUnits);
		selectedJPanel.add(label, BorderLayout.NORTH);
		selectedJPanel.add(scroller, BorderLayout.CENTER);

		selectedJPanel.setBounds(610, 0, 300, 300); // set location and size of
													// panel

		// Add the character panel to display the character selected.
		characterPanel = new JPanel();
		characterPanel.setLayout(new BorderLayout());
		unit = new no();
		charater = new ViewCharacter(unit);
		characterPanel.add(charater, BorderLayout.SOUTH);
		characterPanel.setBounds(100, 160, 300, 370);
		characterPanel.setBackground(Color.BLACK);

		// Add the map panel to display the selected map
		mapPanel = new JPanel();
		mapPanel.setLayout(new BorderLayout());
		map = new ViewMap("");
		mapPanel.add(map, BorderLayout.SOUTH);
		mapPanel.setBounds(610, 800, 130, 50);
		mapPanel.setBackground(Color.blue);

		// Add Buttons to GUI.
		addButton.setBounds(420, 165, 130, 25);
		removeButton.setBounds(420, 190, 130, 25);
		startButton.setBounds(610, 310, 130, 50);
		mapButtonPanel.setBounds(420, 220, 130, 55);
		situationButtonPanel.setBounds(420, 280, 130, 85);

		situationDescription.setBounds(400, 400, 200, 200);

		// Add created panels to GUI.
		this.add(unitPanel);
		this.add(selectedJPanel);
		this.add(characterPanel);
		this.add(addButton);
		this.add(removeButton);
		this.add(startButton);
		this.add(mapButtonPanel);
		this.add(situationButtonPanel);
		this.add(situationDescription);

		setBackground(Color.BLACK);
	}

	private void addUnits() {
		units = new UnitCollection();

		units.add(new Mage());
		units.add(new Warrior());
		units.add(new Genie());
		units.add(new Knight());
		units.add(new Ranger());
		units.add(new Archer());
	}

	private void registerListeners() {
		unitTable.addMouseListener(new MouseAdapter() {

			public void mousePressed(MouseEvent evt) {
				/**
				 * This is where the units are added to Users list
				 */
				int col;
				int row;
				if (unitTable.rowAtPoint(evt.getPoint()) < 0) {
					return;
				}
				col = unitTable.columnAtPoint(evt.getPoint());
				row = unitTable.rowAtPoint(evt.getPoint());

				selectedUnit = units.getUnitAt(row, col);

				/**
				 * This gets the unit that is selected and creates ViewCharacter
				 * to display the image of the character selected by the User.
				 */
				if (unitTable.rowAtPoint(evt.getPoint()) < 0) {
					return;
				}
				col = unitTable.columnAtPoint(evt.getPoint());
				row = unitTable.rowAtPoint(evt.getPoint());
				//
				unit = units.getUnitAt(row, col);

				checkUnit(unit);
				UnitSelection.this.remove(charater); // Remove previous unit
														// displayed
				charater = new ViewCharacter(unit);
				charater.setBounds(100, 165, 300, 350); // Set the location
														// where it will
														// displayed and size of
														// the unit.
				UnitSelection.this.add(charater);

				// System.out.println(unit);
				charater.setVisible(true);
				charater.repaint();
			}

			private void checkUnit(Unit unit) {
				// TODO Auto-generated method stub
				switch (unit.getTitle()) {
				case "Warrior":
					newUnit = new Warrior();
					break;
				case "Theif":
					newUnit = new Theif();
					break;
				case "Ranger":
					newUnit = new Ranger();
					break;
				case "Mage":
					newUnit = new Mage();
					break;
				case "Knight":
					newUnit = new Knight();
					break;
				case "Genie":
					newUnit = new Genie();
					break;
				case "Archer":
					newUnit = new Archer();
					break;

				default:
					break;
				}
			}
		});

		usersUnits.addListSelectionListener(new Listener());
		removeButton.addActionListener(new RemoveButtonListener());
		startButton.addActionListener(new StartGameListener());
		addButton.addActionListener(new AddButtonListener());

		map1.addActionListener(new Map1Listener());
		map2.addActionListener(new Map2Listener());

		situation1.addActionListener(new TDMListener());
		situation2.addActionListener(new CTFListener());
		situation3.addActionListener(new HordeListener());

	}// END registerListeners

	private class Listener implements ListSelectionListener {

		public void valueChanged(ListSelectionEvent e) {
			if (!e.getValueIsAdjusting()) {
				int index = usersUnits.getSelectedIndex();
				if (index != -1)
					System.out.println(index + ". "
							+ usersUnits.getSelectedValue());
			}
		}
	}

	/**
	 * This will remove unit that the User wants to remove from there list.
	 * 
	 * @author Brian
	 * 
	 */
	private class RemoveButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			int index = usersUnits.getSelectedIndex(); // Index of the unit to
														// be removed
			Unit unitChoosen = userSelect.getElementAt(index); // Unit that will
																// be removed

			if (index >= 0) {
				userSelect.remove(unitChoosen); // Remove unit choosen.
				usersUnits.setSelectedIndex(0);

			}
		}
	}// END RemoveButtonListener

	/**
	 * This method will Start the game once the Start Game button is pressed.
	 * 
	 * @author Brian
	 * 
	 */
	private class StartGameListener implements ActionListener {

		public void actionPerformed(ActionEvent e) {
			Player1.addUnit(new Captain());
			Player1.getUnitsInstance().get(0).setTeam(1);
			int count = 0;
			for (Unit unit : userSelect.getUnits()) {
				Player1.addUnit(unit);
				unit.setTeam(1);
				unit.setPlace("Unit" + count);
				count++;
			}
			System.out.println("Ready?...... FIGHT!");
			System.out.println();

			gameStart = new MapPanel(titleScreen, mapName, gameType);

			titleScreen.getContentPane().removeAll(); // Remove all panels from
														// JFrame.
			titleScreen.add(gameStart, BorderLayout.CENTER); // Add gameStart to
																// start game.
			titleScreen.setLocation(300, 0);
			titleScreen.setSize(1400, 900);
			titleScreen.getContentPane().setVisible(true);
		}

	}// END StartGameListener

	/**
	 * Listener adds the unit selected by User to their list.
	 * 
	 * @author Brian
	 * 
	 */
	private class AddButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			if (userSelect.getSize() < 5) {

				checkUnit(unit);
				userSelect.add(newUnit); // Adds unit to the selected list
			} else {
				int onlyFive = JOptionPane.showConfirmDialog(null,
						"You can only have 5 units!", "",
						JOptionPane.PLAIN_MESSAGE);
				if (onlyFive == JOptionPane.OK_OPTION)
					return;
				else
					return;
			}
		}
	}// END AddButtonListener.

	private class Map1Listener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			mapName = "map1";
			UnitSelection.this.remove(map);
			map = new ViewMap("Map1");

			map.setBounds(610, 370, 300, 360); // Set the location
			// where it will
			// displayed and size of
			// the unit.
			UnitSelection.this.add(map);

			map.setVisible(true);
			map.repaint();
		}

	}

	private class Map2Listener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			mapName = "map2";
			UnitSelection.this.remove(map);
			map = new ViewMap("Map2");

			map.setBounds(610, 370, 300, 360); // Set the location
			// where it will
			// displayed and size of
			// the unit.
			UnitSelection.this.add(map);

			map.setVisible(true);
			map.repaint();
		}

	}

	private class TDMListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			gameType = "TDM";
			horde = false;
			situationDescription
					.setText("All out battle where either one\nteam dies, or one captain dies");
		}

	}

	private class CTFListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			gameType = "CTF";
			horde = false;
			situationDescription
					.setText("A race to get the other team's\nflag or kill the other teams\ncaptain");
		}

	}

	private class HordeListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			gameType = "Horde";
			setHorde(true);
			situationDescription
					.setText("Eitehr survive the onslought\nof enemies or make your way\nto the captain and kill him");
		}

	}

	private void checkUnit(Unit unit) {
		// TODO Auto-generated method stub
		switch (unit.getTitle()) {
		case "Warrior":
			newUnit = new Warrior();
			break;
		case "Theif":
			newUnit = new Theif();
			break;
		case "Ranger":
			newUnit = new Ranger();
			break;
		case "Mage":
			newUnit = new Mage();
			break;
		case "Knight":
			newUnit = new Knight();
			break;
		case "Genie":
			newUnit = new Genie();
			break;
		case "Archer":
			newUnit = new Archer();
			break;

		default:
			break;
		}
	}

	/**
	 * @return the gameType
	 */
	public String getGameType() {
		return gameType;
	}

	/**
	 * @return the horde
	 */
	public static boolean isHorde() {
		return horde;
	}

	/**
	 * @param horde
	 *            the horde to set
	 */
	public static void setHorde(boolean horde) {
		UnitSelection.horde = horde;
	}
}// END UnitSelection Class