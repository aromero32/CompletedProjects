package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.IOException;
import java.util.Observable;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import model.Maps;
import model.Player1;
import model.Player2;
import model.Room;
import model.SaveGame;
import units.Unit;
import units.Warrior;
import units.no;

@SuppressWarnings("serial")
public class CTF extends Gamemode {
	private Image clear;
	// private Image brackets;
	private Image leTree;
	private Image blood;
	private Image trap;
	private Image rock;
	private Image flag;
	private boolean check;
	private boolean p1UP;
	Graphics2D graphics2d;
	private JButton resetButton;
	private JButton showUnitsButton;
	private JButton quitGameButton;
	private JButton trapButton;
	private GameOver gameOver;
	private String winEnd;
	Random random = new Random();
	private int blink = 0;

	private boolean aiAttack = false;

	private Image chest;

	private Image damageR;
	private Image damageY;
	// private JButton attackButton;
	private Maps maps;

	private Room[][] map;

	private int positionX;
	private int positionY;
	private int col;
	private int row;

	private int oldC;
	private int oldR;
	private Unit selUnit = new Warrior();

	private String winner;
	private String username;
	private String mapName;

	int posX; // used for moving graphics
	int posY; // used for moving graphics

	int positionXstart; // used for moving graphics
	int positionYstart; // used for moving graphics

	private static final int SIZE = 26;

	private TitleScreenGui titleScreen;

	private SaveGame saveGame;

	private JPanel outerPanel;

	/**
	 * 
	 * @param mainFrame
	 *            the TitleScreenGui of the currently running program
	 * @param mapName
	 *            the name of the current map
	 * 
	 *            the TDM constructor
	 */

	public CTF(TitleScreenGui mainFrame, String mapName) {

		this.mapName = mapName;
		check = true;
		p1UP = true;
		titleScreen = mainFrame;
		maps = new Maps();
		setup();
		titleScreen.addWindowListener(new ClosingWindowListener());

	}

	/**
	 * sets up the actual TDM map
	 * 
	 */

	public void setup() {
		setLayout(new BorderLayout());
		outerPanel = new JPanel();
		outerPanel.setLayout(new GridLayout(4, 1));
		outerPanel.setPreferredSize(new Dimension(100, 50));
		add(outerPanel, BorderLayout.EAST);

		makebuttons();
		outerPanel.add(resetButton);
		outerPanel.add(showUnitsButton);
		outerPanel.add(quitGameButton);
		outerPanel.add(trapButton);
		setupPics();
		this.setBackground(Color.white);
	}

	/**
	 * this makes all the buttons that are being used
	 * 
	 */

	private void makebuttons() {

		resetButton = new JButton("End Turn");
		resetButton.addActionListener(new Reset());

		showUnitsButton = new JButton("Use Items");
		showUnitsButton.addActionListener(new ShowUnits());

		quitGameButton = new JButton("Quit Game");
		quitGameButton.addActionListener(new QuitGame());

		trapButton = new JButton("Place Trap");
		trapButton.addActionListener(new PlaceTrap());

	}

	/**
	 * this is used to set up all the used images
	 * 
	 */

	private void setupPics() {
		try {
			// brackets = ImageIO.read(new File("src/images/brackets.png"));
			clear = ImageIO.read(new File("src/images/Clear.png"));
			leTree = ImageIO.read(new File("src/images/tree.png"));
			blood = ImageIO.read(new File("src/UnitImages/blood.png"));
			trap = ImageIO.read(new File("src/images/trap.png"));
			chest = ImageIO.read(new File("src/images/chest.png"));
			rock = ImageIO.read(new File("src/images/pixelrock.png"));
			flag = ImageIO.read(new File("src/images/flag.png"));
			damageR = ImageIO.read(new File("src/images/damageRed.png"));
			damageY = ImageIO.read(new File("src/images/damageYellow.png"));
		}

		catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void update(Observable observed, Object arg) {
		// this is used to update the graphical view
		repaint();
	}

	/**
	 * this is used to paint on everything
	 * 
	 */
	@Override
	public void paintComponent(Graphics g) {
		p1UP = true;
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		graphics2d = g2;

		// GameLogic gameLogic = control.getgLogic();
		/*
		 * calls the same gamelogic that is in control
		 */
		if (mapName == "map1") {
			map = maps.getMap1();
		} else {
			map = maps.getMap2();
		}

		setflags();
		drawThings(g2);
		moveUnit(g2);
		attackUnit(g2);
		drawThings(g2);
		checkDead();
		gameOver();

	}

	private void setflags() {
		// TODO Auto-generated method stub
		map[22][22].setFlag(true);
		map[3][3].setFlag(true);

	}

	/**
	 * 
	 * @param positionX
	 *            x position of where the mouse clicked
	 * @param positionY
	 *            x position of where the mouse clicked
	 * 
	 *            this gets the position where the mouse clicked
	 */
	public void mousePosition(int positionX, int positionY) {
		this.positionX = positionX;
		this.positionY = positionY;
		repaint();
	}

	/**
	 * 
	 * @param g2
	 * 
	 *            this paints the movement blocks on the map as well as moves
	 *            the selected unit, (on the second click)
	 */

	public void moveUnit(Graphics g2) {

		// g2.setColor(new Color(0f, 0.00f, 1f, 1f)); // GREEN
		col = positionX / 50;
		row = positionY / 50;

		if (map[row][col].getHasUnit() && !map[row][col].getUnit().isMoving()
				&& map[row][col].getUnit().canMove()
				&& map[row][col].getUnit().isAlive()) {

			setSelUnit(map[row][col].getUnit());
			selUnit.setMoving(true);
			setMoveRooms(row, col);
			g2.fillRect(col * 50, row * 50, 50, 50);

			oldC = col;
			oldR = row;

			g2.setColor(new Color(0.5f, 0.0f, 1f, .7f));

			boolean moveUp = true;
			boolean moveDown = true;
			boolean moveLeft = true;
			boolean moveRight = true;
			boolean moveUL = true;
			boolean moveUR = true;
			boolean moveDL = true;
			boolean moveDR = true;

			for (int k = 1; k < map[row][col].getUnit().getMovementSpeed() + 1; k++) {
				if (moveUL && map[row - k][col - k].getCanMove() && row >= 3
						&& col >= 3 && row <= 22 && col <= 22) {
					g2.fillRect((col - k) * 50, (row - k) * 50, 50, 50);
				} else {
					moveUL = false;
				}// paints up blocks if canMove
				if (moveUR && map[row - k][col + k].getCanMove() && row >= 3
						&& col >= 3 && row <= 22 && col <= 22) {
					g2.fillRect((col + k) * 50, (row - k) * 50, 50, 50);
				} else {
					moveUR = false;
				}// paints up blocks if canMove
				if (moveDL && map[row + k][col - k].getCanMove() && row >= 3
						&& col >= 3 && row <= 22 && col <= 22) {
					g2.fillRect((col - k) * 50, (row + k) * 50, 50, 50);
				} else {
					moveDL = false;
				}// paints up blocks if canMove
				if (moveDR && map[row + k][col + k].getCanMove() && row >= 3
						&& col >= 3 && row <= 22 && col <= 22) {
					g2.fillRect((col + k) * 50, (row + k) * 50, 50, 50);
				} else {
					moveDR = false;
				}// paints up blocks if canMove
				if (moveRight && map[row][col + k].getCanMove() && row > 2
						&& col > 2 && row < 23 && col < 23) {
					g2.fillRect((col + k) * 50, row * 50, 50, 50);
				} else {
					moveRight = false;
				}// paints right blocks if canMove
				if (moveLeft && map[row][col - k].getCanMove() && row > 2
						&& col > 2 && row < 23 && col < 23) {
					g2.fillRect((col - k) * 50, row * 50, 50, 50);
				} else {
					moveLeft = false;
				}// paints left blocks if canMove
				if (moveDown && map[row + k][col].getCanMove() && row > 2
						&& col > 2 && row < 23 && col < 23) {
					g2.fillRect(col * 50, (row + k) * 50, 50, 50);
				} else {
					moveDown = false;
				} // paints down blocks if canMove
				if (moveUp && map[row - k][col].getCanMove() && row > 2
						&& col > 2 && row < 23 && col < 23) {
					g2.fillRect((col) * 50, (row - k) * 50, 50, 50);
				} else {
					moveUp = false;
				}// paints up blocks if canMove

			}

		} else if (selUnit.isMoving() && selUnit.canMove()
				&& map[row][col].getCanMove()
				&& map[row][col].getUnit().isAlive()) {

			map[oldR][oldC].setCanMove(true);
			map[oldR][oldC].removeUnit();
			map[oldR][oldC].setHasUnit(false);
			map[oldR][oldC].setSelected(false);
			repaint();

			imagePainting(row, col, oldR, oldC);

			map[row][col].setUnitInMap(selUnit);
			selUnit.setRow(row);
			selUnit.setCol(col);
			map[row][col].setHasUnit(true);
			map[row][col].getUnit().setTookTurn(true);

			// this is being called to shut the rooms that were opened by the
			// unit that moved, this is done so other units cannot move to where
			// the previous unit was able to move
			// |
			// |
			// V
			closeRooms();

			if (map[row][col].getDamage()) {
				selUnit.setCurrentHealth(20);
				map[row][col].setCanDamage(false);
			}
			if (map[row][col].isChest() && selUnit.getTeam() == 1) {
				Player1.setPotionQuantity(Player1.getPotionQuantity() + 1);
				Player1.setAttackQuantity(Player1.getAttackQuantity() + 1);
				Player1.setSpeedQuantity(Player1.getSpeedQuantity() + 1);
				map[row][col].setChest(false);
			} else if (map[row][col].isChest() && selUnit.getTeam() == 2) {
				map[row][col].setChest(false);
			}

			if (oldC > col && map[row][col].getUnit().isMoving()) {
				map[row][col].getUnit().setMR(true);
				map[row][col].getUnit().setML(false);
			} else {
				map[row][col].getUnit().setML(true);
				map[row][col].getUnit().setMR(false);
			}
			map[row][col].getUnit().setMoving(false);
			map[row][col].getUnit().setCanMove(false);

		} else {

			map[oldR][oldC].setCanMove(false);
			map[row][col].getUnit().setMoving(false);
		}

	}

	/**
	 * 
	 * @param row2
	 * @param col2
	 * 
	 *            this gets the selected unit's position on the map and sets the
	 *            surrounding rooms to be movable if they can be set to such
	 */

	private void setMoveRooms(int row2, int col2) {
		// TODO Auto-generated method stub

		boolean roomUp = true;
		boolean roomDown = true;
		boolean roomLeft = true;
		boolean roomRight = true;
		boolean roomUL = true;
		boolean roomUR = true;
		boolean roomDL = true;
		boolean roomDR = true;

		for (int k = 1; k < map[row2][col2].getUnit().getMovementSpeed() + 1; k++) {
			if (roomRight && row2 >= 3 && col2 >= 3 && row2 <= 22 && col2 <= 22) {
				map[row2][col2 + k].setCanMove(true);
			} else {
				roomRight = false;
			}// paints right blocks if canMove
			if (roomLeft && row2 >= 3 && col2 >= 3 && row2 <= 22 && col2 <= 22) {
				map[row2][col2 - k].setCanMove(true);
			} else {
				roomLeft = false;
			}// paints left blocks if canMove
			if (roomDown && row2 >= 3 && col2 >= 3 && row2 <= 22 && col2 <= 22) {
				map[row2 + k][col2].setCanMove(true);
			} else {
				roomDown = false;
			} // paints down blocks if canMove
			if (roomUp && row2 >= 3 && col2 >= 3 && row2 <= 22 && col2 <= 22) {
				map[row2 - k][col2].setCanMove(true);
			} else {
				roomUp = false;
			}// paints up blocks if canMove
			if (roomUL && row2 >= 3 && col2 >= 3 && row2 <= 22 && col2 <= 22) {
				map[row2 - k][col2 - k].setCanMove(true);
			} else {
				roomUL = false;
				// roomUp = false;
			}// paints up blocks if canMove
			if (roomUR && row2 >= 3 && col2 >= 3 && row2 <= 22 && col2 <= 22) {
				map[row2 - k][col2 + k].setCanMove(true);
			} else {
				roomUR = false;
				// roomUp = false;
			}// paints up blocks if canMove
			if (roomDL && row2 >= 3 && col2 >= 3 && row2 <= 22 && col2 <= 22) {
				map[row2 + k][col2 - k].setCanMove(true);
			} else {
				roomDL = false;
				// roomUp = false;
			}// paints up blocks if canMove
			if (roomDR && row2 >= 3 && col2 >= 3 && row2 <= 22 && col2 <= 22) {
				map[row2 + k][col2 + k].setCanMove(true);
			} else {
				roomDR = false;
			}// paints up blocks if canMove

		}

	}

	/**
	 * 
	 * 
	 * @param g2
	 * 
	 *            this is used to draw all of the units on the field
	 * 
	 */

	private void drawThings(Graphics2D g2) {
		for (int r = 0; r < SIZE; r++) { // goes through cave
			for (int c = 0; c < SIZE; c++) {

				if (map[r][c].isDeadGuy()) {
					g2.drawImage(blood, c * 50, r * 50 + 10, null);
				}
				if (map[r][c].getDamage()) {
					g2.drawImage(trap, c * 50, r * 50, null);
				}
				if (map[r][c].isChest()) {
					g2.drawImage(chest, c * 50, r * 50, null);
				}
				if (map[r][c].isFlag()) {
					g2.drawImage(flag, c * 50, r * 50, null);
				}

				if (map[r][c].getHasUnit() && map[r][c].getUnit().isAlive()) {
					if (map[r][c].getUnit().getMR()) {
						g2.drawImage(map[r][c].getUnit().getImage(), c * 50,
								r * 50, null);
					} else if (map[r][c].getUnit().getML()) {
						g2.drawImage(map[r][c].getUnit().getImageF(), c * 50,
								r * 50, null);
					} else if (c > 12) {
						g2.drawImage(map[r][c].getUnit().getImage(), c * 50,
								r * 50, null);
					} else {
						g2.drawImage(map[r][c].getUnit().getImageF(), c * 50,
								r * 50, null);
					}
				} else {
					if (map[r][c].isObstruction() && map[r][c].isWater()
							&& c >= 3 && c <= 22 && r >= 3 && r <= 22) {
						g2.drawImage(clear, c * 50, r * 50, null);
					} else if (map[r][c].isObstruction() && c >= 3 && c <= 22
							&& r >= 3 && r <= 22 && mapName.equals("map1")) {
						g2.drawImage(leTree, c * 50, r * 50, null);
					} else if (map[r][c].isObstruction() && c > 3 && c < 22
							&& r > 3 && r < 22 && mapName.equals("map2")) {
						g2.drawImage(rock, c * 50, r * 50, null);
					}

					if ((c == 23 && r > 11 && r < 23)
							|| (c == 24 && r > 11 && r < 23)) {

						if (mapName == "map1") {
							g2.drawImage(leTree, c * 50, r * 50, null);
						}
					}

					else if (c < 3 || c > 22 || r < 3 || r > 22) {
						g2.drawImage(clear, c * 50, r * 50, null);
					}

					// else {
					// g2.drawImage(brackets, c * 50, r * 50, null);
					// }
				}

			}
		}

	}

	/**
	 * 
	 * @return selected unit
	 * 
	 *         returns the currently selected unit
	 */

	public Unit getSelectedUnit() {
		for (int i = 0; i < map.length; i++) {
			for (int j = 0; j < map.length; j++) {
				if (map[i][j].getSelected()) {
					return map[i][j].getUnit();
				}
			}
		}
		return new no();
	}

	/**
	 * 
	 * @param selUnit
	 *            sets the selected unit to whatever you want
	 */
	public void setSelUnit(Unit selUnit) {
		this.selUnit = selUnit;
	}

	/**
	 * 
	 * @return selUnit returns the selected unit, (the unit that was currently
	 *         clicked on)
	 */
	public Unit getSelUnit() {
		return selUnit;
	}

	/**
	 * 
	 * @author Alex
	 * 
	 *         this is the listener that allows the turn to end and the other
	 *         players turn to start
	 */

	private class Reset implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {

			for (int r = 0; r < map.length; r++) {
				for (int c = 0; c < map.length; c++) {
					p1UP = true;
					// if (check == true && map[r][c].getUnit().getTeam() == 1)
					// {
					// map[r][c].getUnit().setCanMove(false);
					// map[r][c].getUnit().setCanAttack(false);
					// map[r][c].getUnit().setTookTurn(true);
					//
					// }

					// if (map[r][c].getUnit().getTeam() == 2
					// && map[r][c].getHasUnit()
					// && !map[r][c].getUnit().isTookTurn()) {
					// map[r][c].getUnit().setCanMove(true);
					// map[r][c].getUnit().setCanAttack(true);
					// } else
					// if (map[r][c].getUnit().getTeam() == 1
					// && map[r][c].getHasUnit()
					// && !map[r][c].getUnit().isTookTurn()) {
					// map[r][c].getUnit().setCanMove(true);
					// map[r][c].getUnit().setCanAttack(true);
					// } else if (map[r][c].getUnit().getTeam() == 2
					// && map[r][c].getHasUnit()
					// && map[r][c].getUnit().isTookTurn()) {
					// map[r][c].getUnit().setCanMove(false);
					// map[r][c].getUnit().setCanAttack(false);
					// } else
					if (map[r][c].getUnit().getTeam() == 1
							&& map[r][c].getHasUnit()
							&& map[r][c].getUnit().isTookTurn()) {
						map[r][c].getUnit().setCanMove(true);
						map[r][c].getUnit().setCanAttack(true);
					}
					// else if (map[r][c].getUnit() == null) {
					// return;
					// }
					map[r][c].getUnit().setTookTurn(
							!map[r][c].getUnit().isTookTurn());

				}

			}
			// check = false;
			for (int r = 0; r < SIZE; r++) {
				for (int c = 0; c < SIZE; c++) {
					if (map[r][c].getHasUnit()) {

					} else {
						map[r][c].setCanMove(false);
						map[r][c].setCanAttack(false);
					}
				}
			}
			CTF.this.moveAI();
		}
	}

	/**
	 * 
	 * @param g2
	 * 
	 *            paints the attack boxes as well as attacks the clicked on unit
	 */

	public void attackUnit(Graphics g2) {
		p1UP = true;
		g2.setColor(new Color(1f, 0.0f, 0.0f, 0.4f)); // red
		col = positionX / 50;
		row = positionY / 50;

		if (map[row][col].getHasUnit()
				&& !map[row][col].getUnit().isAttacking()
				&& map[row][col].getUnit().canAttack()
				&& map[row][col].getUnit().isAlive()) {
			setSelUnit(map[row][col].getUnit());
			selUnit.setAttacking(true);
			setAttackRooms(row, col);

			g2.fillRect(col * 50, row * 50, 50, 50);

			oldC = col;
			oldR = row;

			/*
			 * change booleans for attack ones
			 */
			boolean atkUp = true;
			boolean atkDown = true;
			boolean atkLeft = true;
			boolean atkRight = true;
			boolean atkUR = true;
			boolean atkUL = true;
			boolean atkDR = true;
			boolean atkDL = true;

			/*
			 * change .getMovementSpeed for getattackrange used getmovementspeed
			 * for testing purposes the rest should work
			 */
			for (int k = 1; k < map[row][col].getUnit().getAttackRange() + 1; k++) {
				if (atkRight && map[row][col + k].canAttack() && row > 2
						&& col > 2 && row < 23 && col < 23) {

					g2.fillRect((col + k) * 50, row * 50, 50, 50);

				} else {
					atkRight = false;
				}// paints right blocks if canMove
				if (atkLeft && map[row][col - k].canAttack() && row > 2
						&& col > 2 && row < 23 && col < 23) {
					g2.fillRect((col - k) * 50, row * 50, 50, 50);
				} else {
					atkLeft = false;
				}// paints left blocks if canMove
				if (atkDown && map[row + k][col].canAttack() && row > 2
						&& col > 2 && row < 23 && col < 23) {
					g2.fillRect(col * 50, (row + k) * 50, 50, 50);
				} else {
					atkDown = false;
				} // paints down blocks if canMove
				if (atkUp && map[row - k][col].canAttack() && row > 2
						&& col > 2 && row < 23 && col < 23) {
					g2.fillRect((col) * 50, (row - k) * 50, 50, 50);
				} else {
					atkUp = false;
				}// paints up blocks if canMove
				if (atkUR && map[row - k][col + k].canAttack() && row > 2
						&& col > 2 && row < 23 && col < 23) {
					g2.fillRect((col + k) * 50, (row - k) * 50, 50, 50);
				} else {
					atkUR = false;
				}// paints up blocks if canMove
				if (atkUL && map[row - k][col - k].canAttack() && row > 2
						&& col > 2 && row < 23 && col < 23) {
					g2.fillRect((col - k) * 50, (row - k) * 50, 50, 50);
				} else {
					atkUL = false;
				}// paints up blocks if canMove
				if (atkDR && map[row + k][col + k].canAttack() && row > 2
						&& col > 2 && row < 23 && col < 23) {
					g2.fillRect((col + k) * 50, (row + k) * 50, 50, 50);
				} else {
					atkDR = false;
				}// paints up blocks if canMove
				if (atkDL && map[row + k][col - k].canAttack() && row > 2
						&& col > 2 && row < 23 && col < 23) {
					g2.fillRect((col - k) * 50, (row + k) * 50, 50, 50);
				} else {
					atkDL = false;
				}// paints up blocks if canMove

			}
		} else if (selUnit.isAttacking() && selUnit.canAttack()
				&& map[row][col].canAttack()
				&& map[row][col].getUnit().isAlive()) { // second
			// click and
			// can he
			// move
			// there

			if (map[row][col].getHasUnit()
					&& map[row][col].getUnit().getTeam() != map[oldR][oldC]
							.getUnit().getTeam()) {

				map[row][col].getUnit().setCurrentHealth(
						map[oldR][oldC].getUnit().getAttackDamage());

				if (map[row][col].getUnit().getTeam() != selUnit.getTeam()) {
					damageUnitGraphics();
					repaint();
				}

				map[oldR][oldC].getUnit().setCanAttack(false);

				map[oldR][oldC].getUnit().setTookTurn(true);

			} else {
				selUnit.setAttacking(false);
			}
		} else {
			selUnit.setAttacking(false);
		}

	}

	/**
	 * 
	 * @param r
	 *            row of the selected unit
	 * @param c
	 *            column of the selected unit
	 * 
	 *            this uses the points that the selected unit is currently in
	 *            and sets the rooms surrounding said unit as attackable rooms
	 */

	public void setAttackRooms(int r, int c) {
		boolean roomUp = true;
		boolean roomDown = true;
		boolean roomLeft = true;
		boolean roomRight = true;

		for (int k = 1; k < map[r][c].getUnit().getAttackRange() + 1; k++) {
			if (roomRight && r >= 3 && c >= 3 && r <= 22 && c <= 22) {
				map[r][c + k].setCanAttack(true);
			} else {
				roomRight = false;
			}// paints right blocks if canMove
			if (roomLeft && r >= 3 && c >= 3 && r <= 22 && c <= 22) {
				map[r][c - k].setCanAttack(true);
			} else {
				roomLeft = false;
			}// paints left blocks if canMove
			if (roomDown && r >= 3 && c >= 3 && r <= 22 && c <= 22) {
				map[r + k][c].setCanAttack(true);
			} else {
				roomDown = false;
			} // paints down blocks if canMove
			if (roomUp && r >= 3 && c >= 3 && r <= 22 && c <= 22) {
				map[r - k][c].setCanAttack(true);
			} else {
				roomUp = false;
			}// paints up blocks if canMove
			if (roomUp && roomLeft && r >= 3 && c >= 3 && r <= 22 && c <= 22) {
				map[r - k][c - 1].setCanAttack(true);
			} else {
				// roomUp = false;
				// roomLeft = false;
			}
			if (roomUp && roomRight && r >= 3 && c >= 3 && r <= 22 && c <= 22) {
				map[r - k][c + 1].setCanAttack(true);
			} else {
				// roomUp = false;
				// roomRight = false;
			}
			if (roomDown && roomRight && r >= 3 && c >= 3 && r <= 22 && c <= 22) {
				map[r + k][c + 1].setCanAttack(true);
			} else {
				// roomDown = false;
				// roomRight = false;
			}
			if (roomDown && roomLeft && r >= 3 && c >= 3 && r <= 22 && c <= 22) {
				map[r + k][c - 1].setCanAttack(true);
			} else {
				// roomDown = false;
				// roomLeft = false;
			}
		}
	}

	/**
	 * this is the listener that tells the use item menu to pop up
	 * 
	 * @author Alex
	 * 
	 */
	private class ShowUnits implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			new UseItemView(CTF.this);
		}
	}

	/**
	 * this checks the entire map for a dead unit
	 * 
	 * @author Alex
	 */
	private void checkDead() {
		// TODO Auto-generated method stub
		for (int i = 0; i < SIZE; i++) {
			for (int j = 0; j < SIZE; j++) {
				if (map[i][j].getUnit().getCurrentHealth() <= 0
						&& !map[i][j].getUnit().getTitle().equals("no")) {
					map[i][j].setHasUnit(false);
					map[i][j].removeUnit();
					map[i][j].setCanMove(true);
					map[i][j].setDeadGuy(true);
					// the unit has died
				}
			}
		}
	}

	/**
	 * This method asks the user of they want to their game before quiting the
	 * game.
	 * 
	 * @author Brian
	 * 
	 */
	private class QuitGame implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			// Ask User if they want to save their game
			int answer = JOptionPane.showConfirmDialog(null, "Save Game?",
					"Sava Game", JOptionPane.YES_NO_OPTION);
			if (answer == JOptionPane.YES_OPTION) {
				// Data is saved using User's name.
				username = JOptionPane.showInputDialog("User name:");
				if (username.equals(null))
					return; // Returns the user to game if the do not enter a
							// name or press the cancel button.s
				username += ".dat";
				saveGame = new SaveGame(username);
				titleScreen.dispose(); // Closes game panel.
				titleScreen = new TitleScreenGui(); // Returns user to Main Game
													// Screen.
			}
		}
	}// END QuitGame method

	private class PlaceTrap implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			// Ask User if they want to save their game
			map[row][col].setCanDamage(true);
		}
	}

	/**
	 * This method as the User if the want to save their data when the go to
	 * close the window.
	 * 
	 * @author Brian
	 * 
	 */
	private class ClosingWindowListener implements WindowListener {
		public void windowClosing(WindowEvent arg0) {
			// Ask User if they want to save their game
			int answer = JOptionPane.showConfirmDialog(null, "Save Game?",
					"Sava Game", JOptionPane.YES_NO_OPTION);
			if (answer == JOptionPane.YES_OPTION) {
				// Data is saved using User's name.
				username = JOptionPane.showInputDialog("User name:");
				if (username.equals(null))
					return; // Returns the user to game if the do not enter a
							// name or press the cancel button.s
				username += ".dat";
				saveGame = new SaveGame(username);
				titleScreen.dispose(); // Closes game panel.
				titleScreen = new TitleScreenGui(); // Returns user to Main Game
													// Screen.
			}
		}

		/**
		 * THESE METHODS BELOW ARE NOT USED!!!!!!!!!
		 */
		@Override
		public void windowActivated(WindowEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void windowDeactivated(WindowEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void windowDeiconified(WindowEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void windowIconified(WindowEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void windowOpened(WindowEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void windowClosed(WindowEvent arg0) {
			// TODO Auto-generated method stub

		}
	}// END ClosingWindowListener method.

	/**
	 * 
	 * @return true if it is player1's turn and false if it's not
	 * @author Alex
	 */
	public boolean isP1UP() {
		return p1UP;
	}

	/*
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */
	public void imagePainting(int newX, int newY, int oldX, int oldY) {
		posY = newX * 50;
		posX = newY * 50;

		positionYstart = oldX * 50;
		positionXstart = oldY * 50;

		// if(posX > positionXstart || posY > positionYstart)

		if (posY > positionYstart && posX > positionXstart) {
			moveDownRight();
		} else if (posX > positionXstart && posY < positionYstart) {
			moveUpRight();
		} else if (posY > positionYstart && posX < positionXstart) {
			moveDownLeft();
		} else if (posX < positionXstart && posY < positionYstart) {
			moveUpLeft();
		} else if (posY < positionYstart || posX > positionXstart) {
			moveUpRight();
		} else if (posY > positionYstart || posX < positionXstart) {
			moveDownLeft();
		}
		positionXstart = posX;
		positionYstart = posY;
		repaint();
		paintComponentGraphics(this.getGraphics());
		repaint();

	}// End setPosition()

	public void moveDownRight() {
		while (posX > positionXstart || posY > positionYstart) {
			if (posX > positionXstart && posY > positionYstart) {
				positionXstart += 15;
				positionYstart += 15;
				repaint();
				paintComponentGraphics(this.getGraphics());
			} else if (posX > positionXstart) {
				positionXstart += 15;
				repaint();
				paintComponentGraphics(this.getGraphics());

			} else if (posY > positionYstart) {
				positionYstart += 15;
				repaint();
				paintComponentGraphics(this.getGraphics());
			}

			// pause current thread
			try {
				Thread.sleep(25);// 1/10 sec
			} catch (InterruptedException exc) {
			}

		}// end while()

	}// END moveDownRight()

	public void paintComponentGraphics(Graphics g) {
		// super.paintComponents(g);
		Graphics2D g2 = (Graphics2D) g;

		if (posX > positionXstart) {

			g2.drawImage(selUnit.getImageF(), positionXstart, positionYstart,
					null);
		} else {
			g2.drawImage(selUnit.getImage(), positionXstart, positionYstart,
					null);
		}

	}

	public void moveUpRight() {
		while (posX > positionXstart || posY < positionYstart) {
			if (posX > positionXstart && posY < positionYstart) {
				positionXstart += 15;
				positionYstart -= 15;
				repaint();
				paintComponentGraphics(this.getGraphics());
			} else if (posX > positionXstart) {
				positionXstart += 15;
				repaint();
				paintComponentGraphics(this.getGraphics());

			} else if (posY < positionYstart) {
				positionYstart -= 15;
				// repaint();
				paintComponentGraphics(this.getGraphics());
			}

			// pause current thread
			try {
				Thread.sleep(25);// 1/10 sec
			} catch (InterruptedException exc) {
			}
		}// end while()

	}// END moveUpRight()

	public void moveDownLeft() {
		while (posX < positionXstart || posY > positionYstart) {
			if (posX < positionXstart && posY > positionYstart) {
				positionXstart -= 15;
				positionYstart += 15;
				repaint();
				paintComponentGraphics(this.getGraphics());
			} else if (posX < positionXstart) {
				positionXstart -= 15;
				repaint();
				paintComponentGraphics(this.getGraphics());

			} else if (posY > positionYstart) {
				positionYstart += 15;
				repaint();
				paintComponentGraphics(this.getGraphics());
			}

			// pause current thread
			try {
				Thread.sleep(25);// 1/10 sec
			} catch (InterruptedException exc) {
			}

		}// end while()

	}// END moveDownLeft()

	public void moveUpLeft() {
		while (posX < positionXstart || posY < positionYstart) {
			if (posX < positionXstart && posY < positionYstart) {
				positionXstart -= 15;
				positionYstart -= 15;
				repaint();
				paintComponentGraphics(this.getGraphics());
			} else if (posX < positionXstart) {
				positionXstart -= 15;
				repaint();
				paintComponentGraphics(this.getGraphics());

			} else if (posY < positionYstart) {
				positionYstart -= 15;
				repaint();
				paintComponentGraphics(this.getGraphics());
			}

			// pause current thread
			try {
				Thread.sleep(25);// 1/10 sec
			} catch (InterruptedException exc) {
			}
		}// end while()

	}// END moveUpLeft()

	// this makes is so units can't move into certain rooms
	private void closeRooms() {
		for (int r = 0; r < SIZE; r++) {
			for (int c = 0; c < SIZE; c++) {
				if (map[r][c].getHasUnit()) {

				} else {
					map[r][c].setCanMove(false);
					map[r][c].setCanAttack(false);
				}
			}
		}
	}

	// posX and posY should be on the second click in the attack method
	public void paintComponentGraphicsDamage(Graphics g) {

		Graphics2D g2 = (Graphics2D) g;
		System.out.println("painting a slash");
		g2.drawImage(damageY, col * 50, row * 50, 50, 50, null);
		// pause current thread
		try {
			if (p1UP) {
				Thread.sleep(50);
			} else {
				Thread.sleep(1);
			}
		} catch (InterruptedException exc) {
		}
		g2.drawImage(damageR, col * 50, row * 50, 50, 50, null);
	}

	// method calls the paintComponentGraphicsDamage(Graphics g) method for
	// painting of the slashes over and over
	public void damageUnitGraphics() {

		while (blink < 10) // should have about 30 links from one color to
							// another
		{
			System.out.println(blink);
			paintComponentGraphicsDamage(this.getGraphics());
			blink++;
		}
	}// END damageUnitGraphics()

	private void moveAI() {
		Unit moveUnit;

		for (int i = 0; i < 26; i++) {
			for (int j = 0; j < 26; j++) {
				int randy = random.nextInt(11) + 1;
				// System.out.println(randy);
				if (map[i][j].getHasUnit()
						&& !map[i][j].getUnit().getTitle().equals("Captain")
						&& map[i][j].getUnit().getTeam() == 2) {
					moveUnit = map[i][j].getUnit();

					selUnit = moveUnit;
					switch (randy) {

					case 1:// move down
						if (!map[i + 1][j].getHasUnit()
								&& !map[i + 1][j].isObstruction()) {
							map[i][j].setCanMove(true);
							map[i][j].removeUnit();
							map[i][j].setHasUnit(false);
							// map[i][j].setSelected(false);

							map[i + 1][j].setUnitInMap(moveUnit);
							moveUnit.setRow(i + 1);
							moveUnit.setCol(j);
							map[i + 1][j].setHasUnit(true);
							map[i + 1][j].getUnit().setTookTurn(true);
							if (map[i + 1][j].isChest()) {
								map[i + 1][j].setChest(false);
							}
							repaint();

						}
						break;

					case 2:
					case 3:
					case 4:// move up
						if (!map[i - 1][j].getHasUnit()
								&& !map[i - 1][j].isObstruction()) {
							map[i][j].setCanMove(true);
							map[i][j].removeUnit();
							map[i][j].setHasUnit(false);
							// map[i][j].setSelected(false);

							map[i - 1][j].setUnitInMap(moveUnit);
							moveUnit.setRow(i - 1);
							moveUnit.setCol(j);
							map[i - 1][j].setHasUnit(true);
							map[i - 1][j].getUnit().setTookTurn(true);
							if (map[i - 1][j].isChest()) {
								map[i - 1][j].setChest(false);
							}
							repaint();
						}
						break;

					case 5:
					case 6:// move right
						if (!map[i][j + 1].getHasUnit()
								&& !map[i][j + 1].isObstruction()) {

							map[i][j].setCanMove(true);
							map[i][j].removeUnit();
							map[i][j].setHasUnit(false);
							// map[i][j].setSelected(false);

							map[i][j + 1].setUnitInMap(moveUnit);
							moveUnit.setRow(i);
							moveUnit.setCol(j + 1);
							map[i][j + 1].setHasUnit(true);
							map[i][j + 1].getUnit().setTookTurn(true);
							if (map[i][j + 1].isChest()) {
								map[i][j + 1].setChest(false);
							}
							repaint();
						}
						break;
					case 7:
					case 8:
					case 9:
					case 10:
					case 11:// move left
						if (!map[i][j - 1].getHasUnit()
								&& !map[i][j - 1].isObstruction()) {
							map[i][j].setCanMove(true);
							map[i][j].removeUnit();
							map[i][j].setHasUnit(false);
							// map[i][j].setSelected(false);

							map[i][j - 1].setUnitInMap(moveUnit);
							moveUnit.setRow(i);
							moveUnit.setCol(j - 1);
							map[i][j - 1].setHasUnit(true);
							map[i][j - 1].getUnit().setTookTurn(true);
							if (map[i][j - 1].isChest()) {
								map[i][j - 1].setChest(false);
							}

							repaint();
						}
						break;

					default:
						break;
					}
				}

			}
			aiAttack();

		}
	}

	private void aiAttack() {
		p1UP = false;
		for (Unit attckingUnit : Player2.getUnitsInstance()) {
			for (int r = attckingUnit.getRow() - 1; r < attckingUnit.getRow() + 1; r++) {
				for (int c = attckingUnit.getCol() - 1; c < attckingUnit
						.getCol() + 1; c++) {

					if (map[r][c].getHasUnit()
							&& map[r][c].getUnit().getTeam() == 1) {
						aiAttack = true;
						map[r][c].getUnit().setCurrentHealth(
								attckingUnit.getAttackDamage());

						row = r;
						col = c;

						damageUnitGraphics();
					}

				}

			}
		}
		blink = 0;
	}

	// This ends the Game
	/**
	 * ends the game when the end conditions are met
	 * 
	 */
	private void gameOver() {
		if (Player2.getUnitsLeftNumber() == 0) {
			winner = "Player 1";
			winEnd = "team destroyed";
		} else if (Player1.getUnitsLeftNumber() == 0) {
			winner = "Player 2";
			winEnd = "team destroyed";
		} else if (Player1.getCaptain().getCurrentHealth() <= 0) {
			winner = "Player 2";
			winEnd = "cap killed";
		} else if (Player2.getCaptain().getCurrentHealth() <= 0) {
			winner = "Player 1";
			winEnd = "cap killed";
		} else if (map[22][22].getHasUnit()
				&& map[22][22].getUnit().getTeam() == 1) {
			winner = "Player 1";
			winEnd = "gotFlag";
		} else if (map[3][3].getHasUnit() && map[3][3].getUnit().getTeam() == 2) {
			winner = "Player 2";
			winEnd = "gotFlag";
		} else {
			return;
		}

		gameOver = new GameOver(titleScreen, winner, winEnd);

		titleScreen.getContentPane().removeAll(); // Remove all panels from
													// JFrame.
		titleScreen.add(gameOver, BorderLayout.CENTER);

		titleScreen.setLocation(300, 0);
		titleScreen.setSize(1000, 700);
		titleScreen.getContentPane().setVisible(true);

	}// END gameOver method

}// END TDM Class
