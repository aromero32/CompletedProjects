package view;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

import model.Player1;
import model.Player2;

public class GameOver extends JPanel {
	private ImagePanel gameOverPanel;
	private ImagePanel winningPlayer;
	private ImagePanel win;
	private ImagePanel winningFactorPanel;
	private JButton newGame = new JButton("New Game");
	private String winner;
	private String winningFactor = "";
	private TitleScreenGui titleScreen;

	public GameOver(TitleScreenGui mainFrame, String winner2,
			String winningFactor) {
		titleScreen = mainFrame;
		winner = winner2;
		this.winningFactor = winningFactor;
		newGame.addActionListener(new NewGameListener());
		setUp();
	}// END GameOver Constructor

	private void setUp() {
		setLayout(null);
		gameOverPanel = new ImagePanel("src/images/gameover.png", Color.BLACK);
		gameOverPanel.setBounds(30, 0, 910, 150);
		/**
		 * This will print the images of which player has one the game.
		 */
		if (winner.equals("Player 1")) {
			winningPlayer = new ImagePanel("src/images/Player1.png",
					Color.BLACK);
		} else if (winner.equals("Player 2")) {
			winningPlayer = new ImagePanel("src/images/enemy.png", Color.BLACK);
		}
		winningPlayer.setBounds(190, 160, 590, 135);

		win = new ImagePanel("src/images/wins.png", Color.BLACK);
		win.setBounds(290, 310, 380, 130);

		if (winningFactor.equals("team destroyed")) {
			winningFactorPanel = new ImagePanel("src/images/teamkilled.png",
					Color.BLACK);
		} else if (winningFactor.equals("cap killed")) {
			winningFactorPanel = new ImagePanel("src/images/captainkilled.png",
					Color.BLACK);
		} else {
			winningFactorPanel = new ImagePanel("src/images/flagcaptured.png",
					Color.BLACK);
		}
		winningFactorPanel.setBounds(30, 450, 915, 220);
		newGame.setBounds(730, 360, 100, 30);

		add(gameOverPanel);
		add(winningPlayer);
		add(win);
		add(winningFactorPanel);
		// add(newGame);
		setLocation(300, 0);
		setSize(1000, 310);
		setVisible(true);
		setBackground(Color.BLACK);

	}// END Setup

	private class NewGameListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			Player1.reset();
			Player2.reset();
			titleScreen.dispose();
			titleScreen = new TitleScreenGui();
		}

	}

	// public static void main(String[] args)
	// {
	// new GameOver(titleScreen, "Player 1");
	// }
}// END GameOver Class
