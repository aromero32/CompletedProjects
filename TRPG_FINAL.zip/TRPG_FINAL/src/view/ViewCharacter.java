package view;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;

import units.Unit;

public class ViewCharacter extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// private JPanel backPanel;
	private Unit unit; // this is the unit that you want to select
	private ImagePanel character;

	public ViewCharacter(Unit unit) {
		this.unit = unit;
		setupLayout();
		registerListers();
	}

	private void setupLayout() {
		// this.setLayout(new BorderLayout());
		// backPanel = new JPanel();
		character = null;

		switch (unit.getTitle()) {
		case "Warrior":
			character = new ImagePanel("src/images/GUIWarrior.png", Color.BLACK);
			this.repaint();
			break;

		case "Knight":
			character = new ImagePanel("src/images/GUIKnight.png", Color.BLACK);
			this.repaint();
			break;
			
		case "Mage":
			character = new ImagePanel("src/images/GUIWizard.png", Color.BLACK);
			this.repaint();
			break;
			
		case "Archer":
			character = new ImagePanel("src/images/GUIArcher.png", Color.BLACK);
			this.repaint();
			break;
			
		case "Genie":
			character = new ImagePanel("src/images/GUIGenieS.png", Color.BLACK);
			this.repaint();
			break;
			
		case "Ranger":
			character = new ImagePanel("src/images/GUIRanger.png", Color.BLACK);
			this.repaint();
			break;
			
		case "no":
			character = new ImagePanel("src/images/black.png", Color.BLACK);
			this.repaint();
		default:
			break;
		}

		character.setPreferredSize(new Dimension(300, 450));
		character.setBounds(0, 0, 300, 370);
		this.add(character);
		this.setVisible(true);
		this.setSize(300, 370);
		setBackground(Color.BLACK);

	}

	private void registerListers() {
		// TODO Auto-generated method stub

	}

	// public static void main(String[] args) {
	// new ViewCharacter(new Warrior(0, 0, 0, "ok", 0, 0));
	// }

	@Override
	public String toString() {

		return unit.toString();
	}
}
