package view;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;

public class ViewMap extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// private JPanel backPanel;
	private String leMap; // this is the unit that you want to select
	private ImagePanel map;

	public ViewMap(String map) {
		leMap = map;
		setupLayout();
	}

	private void setupLayout() {
		// this.setLayout(new BorderLayout());
		// backPanel = new JPanel();
		map = null;

		switch (leMap) {
		case "Map1":
			map = new ImagePanel("src/images/map.jpg", Color.BLACK);
			this.repaint();
			break;

		case "Map2":
			map = new ImagePanel("src/images/castle.png", Color.BLACK);
			this.repaint();
			break;

		default:
			map = new ImagePanel("src/images/black.png", Color.black);
			this.repaint();
			break;

		}

		map.setPreferredSize(new Dimension(300, 450));
		map.setBounds(0, 0, 300, 370);
		this.add(map);
		this.setVisible(true);
		this.setSize(300, 370);
		setBackground(Color.BLACK);

	}
	// public static void main(String[] args) {
	// new ViewCharacter(new Warrior(0, 0, 0, "ok", 0, 0));
	// }

}
