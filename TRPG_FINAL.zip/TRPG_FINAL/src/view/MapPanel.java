package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;
import javax.swing.JScrollPane;

@SuppressWarnings("serial")
public class MapPanel extends JPanel {

	private TDM tdmGM;
	private CTF ctfGM;
	private Horde hrdGM;

	private int gm;

	private ImagePanel background;
	private int positionX;
	private int positionY;

	private String mapName;

	private TitleScreenGui titleScreen;

	public MapPanel(TitleScreenGui mainFrame, String mapName, String gameType) {
		this.mapName = mapName;
		titleScreen = mainFrame;
		gamemodeCheck(gameType);
		setUp();
	}

	private void gamemodeCheck(String gameType) {
		// TODO Auto-generated method stub
		switch (gameType) {
		case "TDM":
			tdmGM = new TDM(titleScreen, mapName);
			ctfGM = null;
			hrdGM = null;

			tdmGM.setOpaque(false);
			tdmGM.addMouseListener(new Position());

			gm = 1;
			break;
		case "CTF":
			ctfGM = new CTF(titleScreen, mapName);
			tdmGM = null;
			hrdGM = null;

			ctfGM.setOpaque(false);
			ctfGM.addMouseListener(new Position());

			gm = 2;
			break;
		case "Horde":
			hrdGM = new Horde(titleScreen, mapName);
			ctfGM = null;
			tdmGM = null;

			hrdGM.setOpaque(false);
			hrdGM.addMouseListener(new Position());

			gm = 3;
			break;

		default:
			break;
		}
	}

	private void setUp() {

		if (mapName == "map1") {
			background = new ImagePanel("src/images/mapR.jpg", Color.CYAN);
		} else {
			background = new ImagePanel("src/images/dungeonMap.png", Color.CYAN);
		}
		background.setLayout(new BorderLayout());

		switch (gm) {
		case 1:
			background.add(tdmGM, BorderLayout.CENTER);
			break;
		case 2:
			background.add(ctfGM, BorderLayout.CENTER);
			break;
		case 3:
			background.add(hrdGM, BorderLayout.CENTER);
			break;
		default:
			break;
		}

		JScrollPane scrollPane = new JScrollPane(background);
		background.setPreferredSize(new Dimension(1300, 1300));

		setLayout(new BorderLayout());
		add(scrollPane, BorderLayout.CENTER);
		setSize(1100, 500);
		setVisible(true);
	}

	private class Position extends MouseAdapter {

		@Override
		public void mousePressed(MouseEvent e) {
			positionX = e.getX();
			positionY = e.getY();
			switch (gm) {
			case 1:
				tdmGM.mousePosition((positionX / 50) * 50,
						(positionY / 50) * 50);
				break;
			case 2:
				ctfGM.mousePosition((positionX / 50) * 50,
						(positionY / 50) * 50);
				break;
			case 3:
				hrdGM.mousePosition((positionX / 50) * 50,
						(positionY / 50) * 50);
				break;
			default:
				break;
			}

			// System.out.println(positionX / 50 + " " + positionY / 50);
		}

	}

	// public static void main(String[] args) {
	// new MapPanel();
	// }

}
