package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Label;

import javax.swing.JPanel;

import model.User;

@SuppressWarnings("serial")
public class UserPanel extends JPanel {
	private JPanel namePanel;
	private String name;

	public UserPanel(User user) {
		name = user.getName();
		setUpGui();

	}

	private void setUpGui() {
		namePanel = new JPanel();
		namePanel.setLayout(new BorderLayout());
		namePanel.add(new Label(name), BorderLayout.NORTH);
		namePanel.setBackground(Color.BLACK);
		namePanel.setForeground(Color.WHITE);
	}
}




/*this is gonna show the user name and his current units and their status*/
