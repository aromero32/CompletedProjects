package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.Serializable;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextArea;

import model.ItemList;
import model.Player1;
import model.Player2;
import model.UnitCollectionAgain;
import units.Unit;

public class UseItemView extends JFrame implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3645756418450444730L;

	private UnitCollectionAgain playersUnits;
	private JTable uniTable;

	private Unit selectedUnit;

	private ItemList playersItems;
	private JTable itemList;

	private JButton potionButton;
	private JButton speedBoostButton;
	private JButton attackBoostButton;

	private JTextArea itemDescription;

	private TDM tdm;
	private CTF ctf;
	private Horde horde;

	private int mode;

	private JPanel bPanel;

	public UseItemView(TDM tdm) {

		this.tdm = tdm;
		mode = 1;
		makeButton();
		setup();
		regButtons();
		makeleTable();
	}

	public UseItemView(CTF ctf) {
		this.ctf = ctf;
		mode = 2;
		makeButton();
		setup();
		regButtons();
		makeleTable();
	}

	public UseItemView(Horde horde) {
		this.horde = horde;
		mode = 3;
		makeButton();
		setup();
		regButtons();
		makeleTable();
	}

	private void regButtons() {
		// TODO Auto-generated method stub
		potionButton.addActionListener(new usePotion());
		attackBoostButton.addActionListener(new useAB());
		speedBoostButton.addActionListener(new useSB());
		uniTable.addMouseListener(new MouseAdapter() {

			public void mousePressed(MouseEvent evt) {
				int col = uniTable.columnAtPoint(evt.getPoint());
				int row = uniTable.rowAtPoint(evt.getPoint());
				if (row < 0) {
					return;
				}
				selectedUnit = playersUnits.getUnitAt(row, col);
			}
		});

	}

	private void makeButton() {
		// TODO Auto-generated method stub
		bPanel = new JPanel();
		bPanel.setLayout(new GridLayout(3, 0));
		potionButton = new JButton("Health Potion");
		speedBoostButton = new JButton("Speed Boost");

		attackBoostButton = new JButton("Attack Boost");

		bPanel.add(potionButton);
		bPanel.add(speedBoostButton);
		bPanel.add(attackBoostButton);

	}

	private void setup() {

		itemDescription = new JTextArea();

		itemDescription
				.setText("Healing Potion: gain 80HP on use\nSpeed Boost: gain 1 movement speed on use\nAttack Boost: gain 15 attack damage on use");

		playersUnits = new UnitCollectionAgain();
		uniTable = new JTable(playersUnits);

		playersItems = new ItemList();
		itemList = new JTable(playersItems);
		itemList.setPreferredSize(new Dimension(350, 300));

		setLayout(new BorderLayout());
		this.add(uniTable, BorderLayout.WEST);
		this.add(bPanel, BorderLayout.CENTER);
		this.add(itemDescription, BorderLayout.SOUTH);
		// this.add(itemButton, BorderLayout.SOUTH);
		this.setVisible(true);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setSize(450, 150);
		this.setLocation(650, 250);

	}

	private void makeleTable() {
		if (mode == 1) {

			if (((TDM) tdm).isP1UP()) {
				for (int i = 0; i < Player1.getUnitsInstance().size(); i++) {
					playersUnits.add(Player1.getUnitsInstance().get(i));
				}

			} else {

				for (int i = 0; i < Player2.getUnitsInstance().size(); i++) {
					playersUnits.add(Player2.getUnitsInstance().get(i));
				}

			}
		} else if (mode == 2) {

			if (((CTF) ctf).isP1UP()) {
				for (int i = 0; i < Player1.getUnitsInstance().size(); i++) {
					playersUnits.add(Player1.getUnitsInstance().get(i));
				}

			} else {

				for (int i = 0; i < Player2.getUnitsInstance().size(); i++) {
					playersUnits.add(Player2.getUnitsInstance().get(i));
				}

			}

		} else {

			if (((Horde) horde).isP1UP()) {
				for (int i = 0; i < Player1.getUnitsInstance().size(); i++) {
					playersUnits.add(Player1.getUnitsInstance().get(i));
				}

			} else {

				for (int i = 0; i < Player2.getUnitsInstance().size(); i++) {
					playersUnits.add(Player2.getUnitsInstance().get(i));

				}
			}
		}
	}

	private class usePotion implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {

			System.out.println(selectedUnit.getCurrentHealth());
			if (Player1.getPotionQuantity() > 0) {
				selectedUnit.setCurrentHealth(-80);

				System.out.println(selectedUnit.getCurrentHealth());
				Player1.setPotionQuantity(Player1.getPotionQuantity() - 1);
				uniTable.repaint();
				potionButton.repaint();

			} else {
				potionButton.setBackground(Color.black);
				potionButton.setEnabled(false);
			}
		}
	}

	private class useSB implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			if (Player1.getSpeedQuantity() > 0) {
				if (selectedUnit.getMovementSpeed() >= 4) {
					int tooFast = JOptionPane.showConfirmDialog(null,
							"The movement speed of the unit is maxed out", "",
							JOptionPane.PLAIN_MESSAGE);
					if (tooFast == JOptionPane.OK_OPTION) {
						return;
					} else {
						return;
					}
				} else if (selectedUnit.getTitle().equalsIgnoreCase("Troll")
						|| selectedUnit.getTitle().equalsIgnoreCase("Captain")) {
					int OP = JOptionPane.showConfirmDialog(null,
							"You cannot buff this kind of character: "
									+ selectedUnit.getTitle(), "",
							JOptionPane.PLAIN_MESSAGE);
					if (OP == JOptionPane.OK_OPTION) {
						return;
					} else {
						return;
					}
				}
				selectedUnit
						.setMovementSpeed(selectedUnit.getMovementSpeed() + 1);
				Player1.setSpeedQuantity(Player1.getSpeedQuantity() - 1);
				uniTable.repaint();
				speedBoostButton.repaint();
			} else {
				speedBoostButton.setBackground(Color.black);
				speedBoostButton.setEnabled(false);
			}
		}
	}

	private class useAB implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			System.out.println(selectedUnit.toString());
			if (Player1.getAttackQuantity() > 0) {
				selectedUnit
						.setAttackDamage(selectedUnit.getAttackDamage() + 15);
				Player1.setAttackQuantity(Player1.getAttackQuantity() - 1);
				uniTable.repaint();
				attackBoostButton.repaint();

				if (selectedUnit.getTitle().equalsIgnoreCase("Troll")
						|| selectedUnit.getTitle().equalsIgnoreCase("Captain")) {
					int OP = JOptionPane.showConfirmDialog(null,
							"You cannot buff this kind of character: "
									+ selectedUnit.getTitle(), "",
							JOptionPane.PLAIN_MESSAGE);
					if (OP == JOptionPane.OK_OPTION) {
						return;
					} else {
						return;
					}
				}
			} else {
				attackBoostButton.setBackground(Color.black);
				attackBoostButton.setEnabled(false);
			}
		}
	}

	public static void main(String[] args) {
		new TitleScreenGui();
	}
}
