package items;

/*
 * Class keeps track of an item, (String name of the item)
 */
public abstract class Item {
	private String name;

	public Item() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getBoostUp() {
		return 15;
	}

	public int getMoveBoost() {
		return 1;
	}

	public int getHealthUp() {
		return 80;
	}

}// END Item Class
