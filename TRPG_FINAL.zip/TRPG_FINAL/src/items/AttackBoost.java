package items;

public class AttackBoost extends Item {
	private String name = "";

	public AttackBoost() {
		name = "Attack Boost";
	}

	public String getName() {
		return name;
	}

	@Override
	public int getBoostUp() {
		return 15;
	}

	@Override
	public String toString() {
		String result = "";
		// TODO Auto-generated method stub
		result += "+15 boost to attack";
		return result;
	}

}// END AttackBoost Class
