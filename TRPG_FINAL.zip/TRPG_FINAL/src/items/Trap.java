package items;

public class Trap extends Item
{

	private String name = "";
	private int damage;
	
	public Trap()
	{
		name = "Trap";
		damage = 25;
	}

	public String getName()
	{
		return name;
	}
	
	public int getDamage()
	{
		return damage;
	}
}//END Trap Class
