package items;

public class MoveBoost extends Item {
	private String name = "";

	public MoveBoost() {
		name = "Move Boost";
	}

	public String getName() {
		return name;
	}

	@Override
	public int getMoveBoost() {
		return 1;
	}

	@Override
	public String toString() {
		String result = "";
		// TODO Auto-generated method stub
		result += "+1 boost to movement speed";
		return result;
	}
}// END MoveBoost Class

