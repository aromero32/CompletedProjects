package items;

public class HealthPotion extends Item {
	private String name = "";
	private int healthUp;

	public HealthPotion() {
		name = "Health Potion";
		healthUp = 80;
	}

	public String getName() {
		return name;
	}

	@Override
	public int getHealthUp() {
		return healthUp;
	}

	@Override
	public String toString() {
		String result = "";
		// TODO Auto-generated method stub
		result += "+80 hp";
		return result;
	}
}// END HealthPotion Class
